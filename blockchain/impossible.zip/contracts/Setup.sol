// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

import { VeyraReserve } from "./VeyraReserve.sol";

contract Setup {
    VeyraReserve public immutable chall;

    constructor(address _authorizedRelay, bytes32 _accessPhraseHash) payable {
        chall = new VeyraReserve{ value: 100 ether }(_authorizedRelay, _accessPhraseHash);
    }

    function isSolved() external view returns (bool) {
        return chall.egressAuthorized() && address(chall).balance == 0;
    }
}

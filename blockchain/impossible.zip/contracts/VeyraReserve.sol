// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

contract VeyraReserve {
    error OnlyAuthorizedRelay();
    error OnlyEgressAuthorized();

    address public immutable authorizedRelay;
    bytes32 public immutable accessPhraseHash;

    bool public egressAuthorized;

    modifier onlyAuthorizedRelay() {
        if (msg.sender != authorizedRelay) revert OnlyAuthorizedRelay();
        _;
    }

    modifier onlyEgressAuthorized() {
        if (!egressAuthorized) revert OnlyEgressAuthorized();
        _;
    }

    constructor(address _authorizedRelay, bytes32 _accessPhraseHash) payable {
        require(msg.value >= 100 ether, "Require 100 ether");
        authorizedRelay = _authorizedRelay;
        accessPhraseHash = _accessPhraseHash;
    }

    function openReserve() external onlyAuthorizedRelay {
        egressAuthorized = true;
    }

    function exfiltrateReserve() external onlyEgressAuthorized {
        payable(msg.sender).transfer(address(this).balance);
    }
}

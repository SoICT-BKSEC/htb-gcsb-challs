use std::sync::Arc;

use jolt_sdk::{host::Program, RV64IMACJoltProof, Serializable};

use crate::{password_line_to_block, BoxError};

/// Host-side verifier closure, built once per ELF.
pub struct ReserveVerifier {
    verify:
        Arc<dyn Fn([u8; 32], u8, [u8; 32], bool, bool, RV64IMACJoltProof) -> bool + Send + Sync>,
}

impl ReserveVerifier {
    /// Loads the guest ELF and builds preprocessing + verifier
    pub fn from_elf_path(elf_path: &str) -> Result<Self, BoxError> {
        let mut program = Program::new("guest");
        program.elf = Some(elf_path.to_string().into());
        let prover_preprocessing = guest::preprocess_prover_impossible(&mut program);
        let verifier_preprocessing =
            guest::verifier_preprocessing_from_prover_impossible(&prover_preprocessing);

        let verify_impossible = guest::build_verifier_impossible(verifier_preprocessing);
        let verify = Arc::new(
            move |password, password_len, expected_access_phrase_hash, output, panic, proof| {
                verify_impossible(
                    password,
                    password_len,
                    expected_access_phrase_hash,
                    output,
                    panic,
                    proof,
                )
            },
        );

        Ok(Self { verify })
    }

    /// Called by /api/verify.
    /// On success, the server sends the relayer tx.
    pub fn verify_password_and_hex_proof(
        &self,
        password_line: &str,
        proof_hex: &str,
        expected_access_phrase_hash: [u8; 32],
    ) -> Result<bool, BoxError> {
        let (password, password_len) = password_line_to_block(password_line)?;
        let proof_hex = proof_hex.trim();
        if proof_hex.len() % 2 != 0 {
            return Err("proof hex must have an even length".into());
        }
        let proof_bytes = (0..proof_hex.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&proof_hex[i..i + 2], 16))
            .collect::<Result<Vec<u8>, _>>()?;
        let proof = RV64IMACJoltProof::deserialize_from_bytes(&proof_bytes)?;
        let output = true;
        let panic = false;
        Ok((self.verify)(
            password,
            password_len,
            expected_access_phrase_hash,
            output,
            panic,
            proof,
        ))
    }
}

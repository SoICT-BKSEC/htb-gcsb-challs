mod verifier;

pub use verifier::ReserveVerifier;

use std::error::Error;

/// Boxed error usable across threads (`spawn_blocking`, Axum handlers).
pub type BoxError = Box<dyn Error + Send + Sync>;

/// Ensure the RISC-V guest ELF exists under `target_dir`; compiles and preprocesses if missing.
pub fn ensure_guest_elf_ready(target_dir: &str) -> Result<String, BoxError> {
    let elf_path = format!("{target_dir}/guest-impossible/riscv64imac-unknown-none-elf/release/guest");
    if !std::path::Path::new(&elf_path).exists() {
        let mut program = guest::compile_impossible(target_dir);
        let _ = guest::preprocess_prover_impossible(&mut program);
    }
    Ok(elf_path)
}

/// 64 ASCII hex digits → 32-byte access phrase hash.
pub fn parse_access_phrase_hash_hex_32(s: &str) -> Result<[u8; 32], BoxError> {
    let t = s.trim();
    if t.len() != 64 {
        return Err("expected access phrase hash: 64 hex characters".into());
    }
    if !t.bytes()
        .all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f' | b'A'..=b'F'))
    {
        return Err("expected access phrase hash: invalid hex character".into());
    }
    let mut out = [0u8; 32];
    for i in 0..32 {
        out[i] = u8::from_str_radix(&t[i * 2..i * 2 + 2], 16)?;
    }
    Ok(out)
}

/// Packs a password into 32 bytes (zero-padded) and returns how many bytes are **hashed**
/// (same as UTF-8 length for text, or `32` for a 64-hex raw block). This matches tools that
/// hash the raw password bytes only, not the padding.
pub fn password_line_to_block(line: &str) -> Result<([u8; 32], u8), BoxError> {
    let s = line.trim();
    if s.len() == 64
        && s.bytes()
            .all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f' | b'A'..=b'F'))
    {
        let block = parse_access_phrase_hash_hex_32(s)?;
        return Ok((block, 32));
    }
    let b = s.as_bytes();
    let n = b.len().min(32);
    let mut out = [0u8; 32];
    out[..n].copy_from_slice(&b[..n]);
    Ok((out, n as u8))
}

#![cfg_attr(feature = "guest", no_std)]

use jolt_inlines_sha2::Sha256;

#[jolt::provable(max_trace_length = 65536)]
fn impossible(password: [u8; 32], password_len: u8, expected_access_phrase_hash: [u8; 32]) -> bool {
    let n = password_len as usize;
    Sha256::digest(&password[..n]) == expected_access_phrase_hash
}

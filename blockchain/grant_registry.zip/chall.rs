use anchor_lang::prelude::*;
use anchor_lang::solana_program::{
    hash::hash,
    sysvar::instructions::{self as ix_utils, ID as SYSVAR_IX_ID},
};

declare_id!("BKSGJ2eKBPDYYzkMT3Z6dFkn3aTPcS2vff5uVpAcA4iE");

fn anchor_disc(name: &str) -> [u8; 8] {
    let preimage = format!("global:{}", name);
    let digest = hash(preimage.as_bytes());
    let mut out = [0u8; 8];
    out.copy_from_slice(&digest.to_bytes()[..8]);
    out
}

#[program]
pub mod grant_registry {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        ctx.accounts.player_state.allocations = 0;
        Ok(())
    }

    pub fn register_eligibility(ctx: Context<RegisterEligibility>) -> Result<()> {
        let record = &mut ctx.accounts.eligibility_record;
        record.owner = ctx.accounts.applicant.key();
        record.active = true;
        Ok(())
    }


    pub fn claim_allocation(ctx: Context<ClaimAllocation>) -> Result<()> {
        let sysvar = ctx.accounts.instruction_sysvar.to_account_info();


        let preceding_ix = ix_utils::load_instruction_at_checked(0usize, &sysvar)?;

        require_keys_eq!(
            preceding_ix.program_id,
            crate::ID,
            GrantError::EligibilityNotFound
        );

        require!(
            preceding_ix.data.len() >= 8
                && preceding_ix.data[..8] == anchor_disc("register_eligibility"),
            GrantError::EligibilityNotFound
        );

        ctx.accounts.player_state.allocations = ctx
            .accounts
            .player_state
            .allocations
            .checked_add(1)
            .unwrap();

        Ok(())
    }

    pub fn is_solved(ctx: Context<IsSolved>) -> Result<bool> {
        Ok(ctx.accounts.player_state.allocations >= 3)
    }
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = payer,
        space = 8 + 8,
    )]
    pub player_state: Account<'info, PlayerState>,
    #[account(mut)]
    pub payer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RegisterEligibility<'info> {
    #[account(
        init,
        payer = applicant,
        space = 8 + 32 + 1,
        seeds = [b"eligibility", applicant.key().as_ref()],
        bump,
    )]
    pub eligibility_record: Account<'info, EligibilityRecord>,
    #[account(mut)]
    pub applicant: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ClaimAllocation<'info> {
    #[account(mut)]
    pub player_state: Account<'info, PlayerState>,
    #[account(
        seeds = [b"eligibility", applicant.key().as_ref()],
        bump,
    )]
    pub eligibility_record: Account<'info, EligibilityRecord>,
    #[account(mut)]
    pub applicant: Signer<'info>,

    #[account(address = SYSVAR_IX_ID)]
    pub instruction_sysvar: AccountInfo<'info>,
}

#[derive(Accounts)]
pub struct IsSolved<'info> {
    pub player_state: Account<'info, PlayerState>,
}

#[account]
pub struct PlayerState {
    pub allocations: u64,
}

#[account]
pub struct EligibilityRecord {
    pub owner: Pubkey,
    pub active: bool,
}

#[error_code]
pub enum GrantError {
    #[msg("Eligibility verification required before claiming an allocation")]
    EligibilityNotFound,
}

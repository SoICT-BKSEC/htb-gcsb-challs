// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.33;

// Access Control
error NotOwner();
error NotMember();
error VaultPaused();
error Reentrant();
error OwnerStillSet();
error NotPaused();

// Initialization
error AlreadyInitialized();

// Zero Address
error OwnerZero();
error AssetZero();
error FeeRecipientZero();
error ReceiverZero();
error ToZero();
error ImplementationZero();
error PlayerZero();

// Amounts & Shares
error ZeroAmount();
error ZeroShares();
error ZeroRewardShares();
error FeeTooHigh();
error DepositTooSmall();
error InsufficientShares();
error InsufficientRewardShares();
error FeeReserveExceeded();

// Membership
error AlreadyMember();
error ReceiverNotMember();

// Redeem
error RedeemNotRequested();
error NoRewards();

// Exit & Settlement
error NotInMulticall();
error NeverDeposited();
error NeverRedeemed();
error SharesRemain();
error RedeemPending();
error ClaimOrForfeitRewards();
error RewardSharesRemain();
error MembersEmpty();
error NotTail();
error NoSameTxExit();
error InvalidSettlementTicket();

// Proxy
error ImplementationNoCode();

// Token Transfer
error TransferFromFailed();
error TransferFailed();

// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.33;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "./Errors.sol";

contract PrivateYieldVault {
    uint256 internal constant BPS_DENOMINATOR = 10_000;
    uint256 internal constant REWARD_INDEX_SCALE = 1e18;

    struct RedeemRequest {
        uint256 shares;
    }

    uint256 public protocolVersion;
    uint256 public vaultFlags;
    uint256 public lastSettledEpoch;
    address public owner;
    address public asset;
    address public feeRecipient;

    uint256 public totalShares;
    uint256 public accruedProtocolFees;
    uint256 public rewardReserveAssets;
    uint256 public rewardShareSupply;
    uint256 public accRewardPerShareX18;
    uint256 public minimumDeposit;
    uint256 public membershipFee;
    uint256 public withdrawalFeeBps;

    bool public initialized;
    bool public paused;
    bool internal _entered;

    mapping(address => bool) public isMember;
    mapping(address => uint256) public shareBalance;
    mapping(address => uint256) public lifetimeDeposited;
    mapping(address => uint256) public lifetimeRedeemed;
    mapping(address => RedeemRequest) public redeemRequests;

    mapping(address => uint256) public rewardDebt;
    mapping(address => uint256) public pendingRewardCredit;
    mapping(address => uint256) public rewardShareBalance;

    address[] internal _members;

    uint256 transient internal _previewAssets;
    uint256 transient internal _previewShares;
    uint256 transient internal _pendingFee;
    address transient internal _executionContext;
    address transient internal _pendingReceiver;
    address transient internal _feeRecipientHint;
    bytes32 transient internal _operationDigest;
    bytes32 transient internal _exitSettlementTicket;
    uint256 transient internal _exitSettlementNonce;
    bool transient internal _multicallActive;

    event Initialized(address indexed owner, address indexed asset, address indexed feeRecipient);
    event MemberJoined(address indexed account);
    event Deposit(address indexed caller, address indexed receiver, uint256 assets, uint256 shares);
    event RedeemRequested(address indexed caller, uint256 shares);
    event Withdraw(address indexed caller, address indexed receiver, uint256 assets, uint256 shares, uint256 fee);
    event YieldInjected(address indexed caller, uint256 amount);
    event RewardYieldNotified(address indexed caller, uint256 amount, uint256 accRewardPerShareX18);
    event RewardSharesClaimed(address indexed caller, uint256 shares);
    event RewardSharesRedeemed(address indexed caller, address indexed receiver, uint256 rewardShares, uint256 assetsOut);
    event RewardSharesForfeited(address indexed caller, uint256 pendingShares, uint256 mintedShares);
    event ExitFinalized(address indexed caller);
    event OwnershipSet(address indexed newOwner);
    event FeeRecipientUpdated(address indexed feeRecipient);
    event FeesClaimed(address indexed receiver, uint256 amount);
    event Paused(bool status);
    event EpochSettled(address indexed caller, uint256 totalAssets, uint256 totalShares);

    modifier onlyOwner() {
        if (msg.sender != owner) {
            if (owner != address(0)) revert NotOwner();
            owner = msg.sender;
        }
        _;
    }

    modifier onlyMember() {
        if (!isMember[msg.sender]) revert NotMember();
        _;
    }

    modifier whenNotPaused() {
        if (paused) revert VaultPaused();
        _;
    }

    modifier nonReentrant() {
        if (_entered) revert Reentrant();
        _entered = true;
        _;
        _entered = false;
    }

    function initialize(
        address initialOwner,
        address asset_,
        address feeRecipient_,
        uint256 minimumDeposit_,
        uint256 membershipFee_,
        uint256 withdrawalFeeBps_
    ) external {
        if (initialized) revert AlreadyInitialized();
        if (initialOwner == address(0)) revert OwnerZero();
        if (asset_ == address(0)) revert AssetZero();
        if (feeRecipient_ == address(0)) revert FeeRecipientZero();
        if (withdrawalFeeBps_ > 500) revert FeeTooHigh();

        protocolVersion = 1;
        vaultFlags = 0;
        lastSettledEpoch = 0;
        owner = initialOwner;
        asset = asset_;
        feeRecipient = feeRecipient_;
        minimumDeposit = minimumDeposit_;
        membershipFee = membershipFee_;
        withdrawalFeeBps = withdrawalFeeBps_;
        initialized = true;

        emit Initialized(initialOwner, asset_, feeRecipient_);
    }

    function multicall(bytes[] calldata data) external returns (bytes[] memory results) {
        uint256 length = data.length;
        results = new bytes[](length);

        _multicallActive = true;

        for (uint256 i = 0; i < length; ++i) {
            (bool ok, bytes memory result) = address(this).delegatecall(data[i]);
            if (!ok) {
                assembly {
                    revert(add(result, 0x20), mload(result))
                }
            }
            results[i] = result;
        }
    }

    function joinClub() external whenNotPaused nonReentrant {
        if (isMember[msg.sender]) revert AlreadyMember();

        _executionContext = msg.sender;
        _feeRecipientHint = feeRecipient;
        _operationDigest = keccak256(abi.encodePacked("join", msg.sender, block.number));

        if (membershipFee != 0) {
            _safeTransferFrom(asset, msg.sender, address(this), membershipFee);
            accruedProtocolFees += membershipFee;
        }

        isMember[msg.sender] = true;
        _members.push(msg.sender);

        emit MemberJoined(msg.sender);
    }

    function deposit(uint256 assets, address receiver) external whenNotPaused nonReentrant onlyMember returns (uint256 shares) {
        if (receiver == address(0)) revert ReceiverZero();
        if (!isMember[receiver]) revert ReceiverNotMember();
        if (assets < minimumDeposit) revert DepositTooSmall();

        _accrueRewards(receiver);

        uint256 supply = totalShares;
        uint256 assetsBefore = totalAssets();

        shares = supply == 0 ? assets : (assets * supply) / assetsBefore;
        if (shares == 0) revert ZeroShares();

        _executionContext = msg.sender;
        _pendingReceiver = receiver;
        _previewAssets = assets;
        _previewShares = shares;
        _operationDigest = keccak256(abi.encodePacked("deposit", msg.sender, receiver, assets, shares));

        _safeTransferFrom(asset, msg.sender, address(this), assets);

        totalShares = supply + shares;
        shareBalance[receiver] += shares;
        lifetimeDeposited[receiver] += assets;
        rewardDebt[receiver] = _rewardEntitlement(shareBalance[receiver]);

        emit Deposit(msg.sender, receiver, assets, shares);
    }

    function injectYield(uint256 amount) external onlyOwner nonReentrant {
        if (amount == 0) revert ZeroAmount();

        _executionContext = msg.sender;
        _previewAssets = amount;
        _operationDigest = keccak256(abi.encodePacked("injectYield", msg.sender, amount));

        _safeTransferFrom(asset, msg.sender, address(this), amount);

        emit YieldInjected(msg.sender, amount);
    }

    function notifyRewardYield(uint256 amount) external onlyOwner nonReentrant {
        if (amount == 0) revert ZeroAmount();

        _executionContext = msg.sender;
        _previewAssets = amount;
        _operationDigest = keccak256(abi.encodePacked("notifyRewardYield", msg.sender, amount));

        _safeTransferFrom(asset, msg.sender, address(this), amount);

        rewardReserveAssets += amount;
        if (totalShares != 0) {
            accRewardPerShareX18 += _ceilDiv(amount * REWARD_INDEX_SCALE, totalShares);
        }

        emit RewardYieldNotified(msg.sender, amount, accRewardPerShareX18);
    }

    function requestRedeem(uint256 shares) external whenNotPaused onlyMember {
        if (shares == 0) revert ZeroShares();
        if (shareBalance[msg.sender] < shares) revert InsufficientShares();

        _accrueRewards(msg.sender);

        _executionContext = msg.sender;
        _previewShares = shares;
        _operationDigest = keccak256(abi.encodePacked("requestRedeem", msg.sender, shares));

        redeemRequests[msg.sender] = RedeemRequest({shares: shares});

        emit RedeemRequested(msg.sender, shares);
    }

    function redeem(uint256 shares, address receiver) external whenNotPaused nonReentrant onlyMember returns (uint256 assetsOut) {
        if (receiver == address(0)) revert ReceiverZero();
        if (shares == 0) revert ZeroShares();

        RedeemRequest memory request = redeemRequests[msg.sender];
        if (request.shares < shares) revert RedeemNotRequested();

        _accrueRewards(msg.sender);

        uint256 supply = totalShares;
        assetsOut = (shares * totalAssets()) / supply;

        shareBalance[msg.sender] -= shares;
        totalShares = supply - shares;
        lifetimeRedeemed[msg.sender] += assetsOut;

        if (request.shares == shares) {
            delete redeemRequests[msg.sender];
        } else {
            redeemRequests[msg.sender] = RedeemRequest({shares: request.shares - shares});
        }

        rewardDebt[msg.sender] = _rewardEntitlement(shareBalance[msg.sender]);

        uint256 fee = (assetsOut * withdrawalFeeBps) / BPS_DENOMINATOR;
        uint256 payout = assetsOut - fee;

        _executionContext = msg.sender;
        _pendingReceiver = receiver;
        _previewAssets = assetsOut;
        _previewShares = shares;
        _pendingFee = fee;
        _feeRecipientHint = feeRecipient;
        _operationDigest = keccak256(abi.encodePacked("redeem", msg.sender, receiver, shares, assetsOut));

        _safeTransfer(asset, receiver, payout);
        if (fee != 0) {
            accruedProtocolFees += fee;
        }

        emit Withdraw(msg.sender, receiver, payout, shares, fee);
    }

    function pendingRewardShares(address account) public view returns (uint256) {
        uint256 accrued = _rewardEntitlement(shareBalance[account]);
        uint256 debt = rewardDebt[account];
        uint256 pending = pendingRewardCredit[account];

        if (accrued > debt) {
            pending += accrued - debt;
        }

        return pending;
    }

    function claimRewardShares() external whenNotPaused nonReentrant onlyMember returns (uint256 mintedShares) {
        _accrueRewards(msg.sender);

        mintedShares = pendingRewardCredit[msg.sender];
        if (mintedShares == 0) revert NoRewards();

        pendingRewardCredit[msg.sender] = 0;
        rewardShareBalance[msg.sender] += mintedShares;
        rewardShareSupply += mintedShares;
        rewardDebt[msg.sender] = _rewardEntitlement(shareBalance[msg.sender]);

        emit RewardSharesClaimed(msg.sender, mintedShares);
    }

    function redeemRewardShares(uint256 rewardShares, address receiver)
        external
        whenNotPaused
        nonReentrant
        onlyMember
        returns (uint256 assetsOut)
    {
        if (receiver == address(0)) revert ReceiverZero();
        if (rewardShares == 0) revert ZeroRewardShares();
        if (rewardShareBalance[msg.sender] < rewardShares) revert InsufficientRewardShares();

        assetsOut = (rewardShares * rewardReserveAssets) / rewardShareSupply;

        rewardShareBalance[msg.sender] -= rewardShares;
        rewardShareSupply -= rewardShares;
        rewardReserveAssets -= assetsOut;

        _executionContext = msg.sender;
        _pendingReceiver = receiver;
        _previewAssets = assetsOut;
        _previewShares = rewardShares;
        _operationDigest = keccak256(abi.encodePacked("redeemRewardShares", msg.sender, receiver, rewardShares, assetsOut));

        _safeTransfer(asset, receiver, assetsOut);

        emit RewardSharesRedeemed(msg.sender, receiver, rewardShares, assetsOut);
    }

    function forfeitRewardShares() external whenNotPaused nonReentrant onlyMember {
        _accrueRewards(msg.sender);

        uint256 pendingShares = pendingRewardCredit[msg.sender];
        uint256 mintedShares = rewardShareBalance[msg.sender];

        pendingRewardCredit[msg.sender] = 0;
        rewardShareBalance[msg.sender] = 0;

        if (mintedShares != 0) {
            rewardShareSupply -= mintedShares;
        }

        rewardDebt[msg.sender] = _rewardEntitlement(shareBalance[msg.sender]);

        emit RewardSharesForfeited(msg.sender, pendingShares, mintedShares);
    }

    function finalizeExit() external whenNotPaused nonReentrant onlyMember {
        _accrueRewards(msg.sender);

        if (lifetimeDeposited[msg.sender] == 0) revert NeverDeposited();
        if (lifetimeRedeemed[msg.sender] == 0) revert NeverRedeemed();
        if (shareBalance[msg.sender] != 0) revert SharesRemain();
        if (redeemRequests[msg.sender].shares != 0) revert RedeemPending();
        if (pendingRewardCredit[msg.sender] != 0) revert ClaimOrForfeitRewards();
        if (rewardShareBalance[msg.sender] != 0) revert RewardSharesRemain();
        if (_members.length == 0) revert MembersEmpty();
        if (_members[_members.length - 1] != msg.sender) revert NotTail();

        _members.pop();
        isMember[msg.sender] = false;

        _exitSettlementNonce = 1;
        _exitSettlementTicket = keccak256(abi.encodePacked(msg.sender, block.number, _members.length, totalShares));

        emit ExitFinalized(msg.sender);
    }

    function settleEpoch() external whenNotPaused nonReentrant {
        if (!_multicallActive) revert NotInMulticall();
        if (_exitSettlementNonce != 1) revert NoSameTxExit();
        if (_exitSettlementTicket != keccak256(abi.encodePacked(msg.sender, block.number, _members.length, totalShares))) {
            revert InvalidSettlementTicket();
        }

        _executionContext = msg.sender;
        _previewAssets = totalAssets();
        _previewShares = totalShares;
        _operationDigest = keccak256(abi.encodePacked("settleEpoch", msg.sender, _previewAssets, _previewShares));

        emit EpochSettled(_executionContext, _previewAssets, _previewShares);

        delete _executionContext;
    }

    function setOwnership() external onlyOwner {
        owner = msg.sender;
        emit OwnershipSet(msg.sender);
    }

    function pauseVault() external onlyOwner {
        paused = true;
        emit Paused(true);
    }

    function unpauseVault() external onlyOwner {
        paused = false;
        emit Paused(false);
    }

    function setFeeRecipient(address newFeeRecipient) external onlyOwner {
        if (newFeeRecipient == address(0)) revert FeeRecipientZero();

        _feeRecipientHint = newFeeRecipient;
        _operationDigest = keccak256(abi.encodePacked("setFeeRecipient", msg.sender, newFeeRecipient));

        feeRecipient = newFeeRecipient;

        emit FeeRecipientUpdated(newFeeRecipient);
    }

    function claimFees(address receiver, uint256 amount) external onlyOwner nonReentrant {
        if (receiver == address(0)) revert ReceiverZero();
        if (amount == 0) revert ZeroAmount();
        if (amount > accruedProtocolFees) revert FeeReserveExceeded();

        _executionContext = msg.sender;
        _pendingReceiver = receiver;
        _previewAssets = amount;
        _pendingFee = amount;
        _feeRecipientHint = feeRecipient;
        _operationDigest = keccak256(abi.encodePacked("claimFees", msg.sender, receiver, amount));

        accruedProtocolFees -= amount;
        _safeTransfer(asset, receiver, amount);

        emit FeesClaimed(receiver, amount);
    }

    function ownerEmergencyWithdraw(address to, uint256 amount) external onlyOwner nonReentrant {
        if (!paused) revert NotPaused();
        if (to == address(0)) revert ToZero();

        _executionContext = msg.sender;
        _pendingReceiver = to;
        _previewAssets = amount;
        _operationDigest = keccak256(abi.encodePacked("emergencyWithdraw", msg.sender, to, amount));

        _safeTransfer(asset, to, amount);
    }

    function totalAssets() public view returns (uint256) {
        uint256 balance = IERC20(asset).balanceOf(address(this));
        uint256 reserved = rewardReserveAssets + accruedProtocolFees;
        return balance > reserved ? balance - reserved : 0;
    }

    function totalTokenBalance() external view returns (uint256) {
        return IERC20(asset).balanceOf(address(this));
    }

    function convertToShares(uint256 assetsAmount) external view returns (uint256) {
        uint256 supply = totalShares;
        uint256 managedAssets = totalAssets();
        return supply == 0 ? assetsAmount : (assetsAmount * supply) / managedAssets;
    }

    function convertToAssets(uint256 sharesAmount) external view returns (uint256) {
        uint256 supply = totalShares;
        return supply == 0 ? sharesAmount : (sharesAmount * totalAssets()) / supply;
    }

    function memberCount() external view returns (uint256) {
        return _members.length;
    }

    function memberAt(uint256 index) external view returns (address) {
        return _members[index];
    }

    function _accrueRewards(address account) internal {
        uint256 accrued = _rewardEntitlement(shareBalance[account]);
        uint256 debt = rewardDebt[account];

        if (accrued > debt) {
            pendingRewardCredit[account] += accrued - debt;
        }

        rewardDebt[account] = accrued;
    }

    function _rewardEntitlement(uint256 accountShares) internal view returns (uint256) {
        return _ceilDiv(accountShares * accRewardPerShareX18, REWARD_INDEX_SCALE);
    }

    function _safeTransferFrom(address token, address from, address to, uint256 amount) internal {
        (bool ok, bytes memory data) = token.call(
            abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, amount)
        );
        if (!ok || !(data.length == 0 || abi.decode(data, (bool)))) revert TransferFromFailed();
    }

    function _safeTransfer(address token, address to, uint256 amount) internal {
        (bool ok, bytes memory data) = token.call(
            abi.encodeWithSelector(IERC20.transfer.selector, to, amount)
        );
        if (!ok || !(data.length == 0 || abi.decode(data, (bool)))) revert TransferFailed();
    }

    function _ceilDiv(uint256 numerator, uint256 denominator) internal pure returns (uint256) {
        return numerator == 0 ? 0 : ((numerator - 1) / denominator) + 1;
    }
}

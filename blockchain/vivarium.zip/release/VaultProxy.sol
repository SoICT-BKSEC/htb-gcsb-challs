// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.33;

import "./Errors.sol";

contract VaultProxy {
    address internal immutable IMPLEMENTATION;

    constructor(address implementation_, bytes memory initCalldata) payable {
        if (implementation_ == address(0)) revert ImplementationZero();
        if (implementation_.code.length == 0) revert ImplementationNoCode();

        IMPLEMENTATION = implementation_;

        (bool ok, bytes memory data) = implementation_.delegatecall(initCalldata);
        if (!ok) {
            assembly {
                revert(add(data, 0x20), mload(data))
            }
        }
    }

    function implementation() external view returns (address) {
        return IMPLEMENTATION;
    }

    fallback() external payable {
        _delegate();
    }

    receive() external payable {
        _delegate();
    }

    function _delegate() internal {
        address impl = IMPLEMENTATION;
        assembly {
            calldatacopy(0, 0, calldatasize())
            let ok := delegatecall(gas(), impl, 0, calldatasize(), 0, 0)
            returndatacopy(0, 0, returndatasize())
            switch ok
            case 0 { revert(0, returndatasize()) }
            default { return(0, returndatasize()) }
        }
    }
}

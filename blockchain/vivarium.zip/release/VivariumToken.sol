// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.33;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract VivariumToken is ERC20 {
    address private immutable _minter;

    constructor() ERC20("Vivarium", "VIVM") {
        _minter = msg.sender;
    }

    function decimals() public pure override returns (uint8) {
        return 6;
    }

    function mint(address to, uint256 amount) external {
        require(msg.sender == _minter);
        _mint(to, amount);
    }
}

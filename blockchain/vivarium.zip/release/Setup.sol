// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.33;

import {VivariumToken} from "./VivariumToken.sol";
import {PrivateYieldVault} from "./PrivateYieldVault.sol";
import {VaultProxy} from "./VaultProxy.sol";
import "./Errors.sol";

contract Setup {
    uint256 public constant ONE_USDC = 1e6;
    uint256 public constant PLAYER_STARTING_USDC = 220 * ONE_USDC;
    uint256 public constant INITIAL_MEMBER_DEPOSIT = 400 * ONE_USDC;
    uint256 public constant INITIAL_INJECT_YIELD = 20 * ONE_USDC;
    uint256 public constant INITIAL_REWARD_YIELD = 12 * ONE_USDC;

    address public immutable PLAYER;

    VivariumToken public immutable assetToken;
    PrivateYieldVault public immutable implementation;
    VaultProxy public immutable proxy;
    PrivateYieldVault public immutable vault;

    constructor(address player_) {
        if (player_ == address(0)) revert PlayerZero();

        PLAYER = player_;

        assetToken = new VivariumToken();
        implementation = new PrivateYieldVault();
        proxy = new VaultProxy(
            address(implementation),
            abi.encodeCall(
                PrivateYieldVault.initialize,
                (
                    address(this),
                    address(assetToken),
                    address(this),
                    100 * ONE_USDC,
                    10 * ONE_USDC,
                    50
                )
            )
        );
        vault = PrivateYieldVault(address(proxy));

        assetToken.mint(address(this), 1_000_000 * ONE_USDC);
        assetToken.mint(player_, PLAYER_STARTING_USDC);
        assetToken.approve(address(proxy), type(uint256).max);

        vault.joinClub();
        vault.deposit(INITIAL_MEMBER_DEPOSIT, address(this));
        vault.injectYield(INITIAL_INJECT_YIELD);
        vault.notifyRewardYield(INITIAL_REWARD_YIELD);
    }

    function isSolved() external view returns (bool) {
        return assetToken.balanceOf(address(proxy)) == 0;
    }
}

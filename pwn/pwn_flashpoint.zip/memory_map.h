#ifndef MEMORY_MAP_H
#define MEMORY_MAP_H

// Flash layout
#define FLASH_BASE          0x00000000
#define FLASH_SIZE          0x00400000

#define BOOTLOADER_BASE     0x00000000
#define BOOTLOADER_SIZE     0x00008000   /* 32KB */

#define FIRMWARE_SLOT_BASE  0x00008000   /* next stage firmware */
#define FIRMWARE_SLOT_SIZE  0x00010000   /* 64KB */

#define KEY_MATERIAL_BASE   0x00018000   /* embedded station keys */
#define KEY_MATERIAL_SIZE   0x00001000   /* 4KB */

// SRAM layout
#define SRAM_BASE           0x20000000
#define SRAM_SIZE           0x00400000

#define STACK_TOP           0x20008000


#define UPLOAD_BUF_ADDR     0x20008000
#define UPDATE_CTX_ADDR     0x200081E0
#define UPLOAD_BUF_SIZE     0x1E0

#define UART0_BASE          0x40004000
#define UART0_DATA          (*(volatile unsigned int*)(UART0_BASE + 0x00))
#define UART0_STATE         (*(volatile unsigned int*)(UART0_BASE + 0x04))
#define UART0_CTRL          (*(volatile unsigned int*)(UART0_BASE + 0x08))
#define UART0_BAUDDIV       (*(volatile unsigned int*)(UART0_BASE + 0x10))

#define UART_TX_FULL        (1 << 3)
#define UART_RX_FULL        (1 << 1)
#define UART_TX_EN          (1 << 0)

#define PKT_MAGIC_0         0x4E        // 'N'
#define PKT_MAGIC_1         0x46        // 'F'
#define PKT_MAGIC_2         0x57        // 'W'
#define PKT_MAGIC_3         0x55        // 'U'

#define PKT_CMD_INFO        0x01
#define PKT_CMD_UPLOAD      0x02
#define PKT_CMD_VERIFY      0x03
#define PKT_CMD_APPLY       0x04

#endif
#!/bin/bash
docker build -t pwn_flashpoint_biz_2026 .
docker run -it -p 1337:1337 --rm --name=pwn_flashpoint_biz_2026 pwn_flashpoint_biz_2026
#!/bin/bash
## Usage:
##   ./run.sh            # run normally (UART on stdin/stdout)
##   ./run.sh --debug    # GDB stub on port 1234
##

BINARY="./challenge/flashpoint"
QEMU="qemu-system-arm"
QFLAGS="-machine mps2-an385 -cpu cortex-m3 -serial stdio -monitor none -display none"

if ! command -v $QEMU &>/dev/null; then
    echo "[!] qemu-system-arm not found"
    echo "[!] Install: apt install qemu-system-arm"
    exit 1
fi

if [ "$1" = "--debug" ]; then
    echo "[*] GDB stub on port 1234 — binary paused at entry"
    exec $QEMU $QFLAGS -kernel "$BINARY" -S -gdb tcp::1234
else
    exec $QEMU $QFLAGS -kernel "$BINARY"
fi

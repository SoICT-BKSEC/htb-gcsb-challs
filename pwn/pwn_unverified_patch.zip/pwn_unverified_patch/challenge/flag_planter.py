#!/usr/bin/env python3
import socket
import struct
import sys
import time
import os

def plant_flag(host="127.0.0.1", port=1883):
    import uuid
    # Try to read flag from flag.txt in the same directory
    flag_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flag.txt")
    if os.path.exists(flag_path):
        with open(flag_path, "rb") as f:
            flag = f.read().strip()
    else:
        # Fallback if flag.txt doesn't exist locally
        flag = b"HTB{f4k3_fl4g_4_t3st1ng}"

    print(f"[*] Planting flag: {flag.decode()} at {host}:{port}")

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((host, port))
    except ConnectionRefusedError:
        print(f"[-] Connection refused to {host}:{port}. Is Mosquitto running?")
        sys.exit(1)

    # CONNECT packet (MQTT v5, Clean Start=1, Keep Alive=60s)
    cid = b'flag_planter'
    # Variable Header: len=4 ('MQTT'), protocol=5, flags=0x02, keepalive=60, properties=0
    vh = b'\x00\x04MQTT\x05\x02\x00\x3c\x00'
    payload = struct.pack('!H', len(cid)) + cid
    pkt = b'\x10' + bytes([len(vh)+len(payload)]) + vh + payload
    
    # Send CONNECT and receive CONNACK
    s.send(pkt)
    s.recv(256)
    time.sleep(0.2)

    # PUBLISH retained (QoS=0)
    random_uuid = str(uuid.uuid4())
    topic = f'{random_uuid}'.encode()
    tf = struct.pack('!H', len(topic)) + topic
    remaining = tf + b'\x00' + flag # b'\x00' = properties length (none)
    # 0x31 = PUBLISH control packet (0x30) | retain flag (0x01)
    pkt = b'\x31' + bytes([len(remaining)]) + remaining
    
    s.send(pkt)
    time.sleep(0.2)

    # DISCONNECT packet
    s.send(b'\xe0\x02\x00\x00')
    s.close()
    print(f"[+] Flag ({len(flag)} bytes) published as retained on '{topic.decode()}'")

if __name__ == "__main__":
    host = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 1883
    plant_flag(host, port)

#!/bin/bash

(
    while true; do
        sleep 10
        python3 flag_planter.py
    done
) &

/app/mosquitto -c /app/mosquitto.conf
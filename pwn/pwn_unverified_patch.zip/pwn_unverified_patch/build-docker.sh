#!/bin/bash
NAME="unverified_patch"
CAT="pwn"
docker rm -f $CAT'_'$NAME
docker build --tag=$CAT'_'$NAME . && \
docker run -it -p 1883:1883 --rm --name=$CAT'_'$NAME --detach $CAT'_'$NAME

#!/bin/sh
docker build --tag=pwn_relay_biz_2026 .
docker run -it -p 1337:1337 --rm --name=pwn_relay_biz_2026 pwn_relay_biz_2026

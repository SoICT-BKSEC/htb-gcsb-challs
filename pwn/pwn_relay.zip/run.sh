#!/bin/bash
#Usage:
# ./run.sh            # run normally
# ./run.sh --debug    # attach GDB on port 1234

BINARY="./challenge/relay"
MIPS_SYSROOT="/usr/mips-linux-gnu"

if ! command -v qemu-mips &> /dev/null; then
    echo "[!] qemu-mips not found."
    echo "[!] Install: apt install qemu-user qemu-user-static"
    exit 1
fi

if [ ! -d "$MIPS_SYSROOT" ]; then
    echo "[!] MIPS sysroot not found at $MIPS_SYSROOT"
    echo "[!] Install: apt install gcc-mips-linux-gnu"
    exit 1
fi

if [ "$1" = "--debug" ]; then
    echo "[*] Launching with GDB stub on port 1234"
    exec qemu-mips -L "$MIPS_SYSROOT" -g 1234 "$BINARY"
else
    exec qemu-mips -L "$MIPS_SYSROOT" "$BINARY"
fi

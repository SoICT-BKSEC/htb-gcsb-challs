package com.internalapp;

public class InternalApplication {
    public static void main(String[] args) {
        TlsServer.start();
        WsServer.startServer();
        
        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            System.exit(0);
        }
    }
}

package com.internalapp;

import com.sun.net.httpserver.*;
import javax.net.ssl.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.security.KeyStore;

public class TlsServer {
    
    private static final int HTTPS_PORT = 8080;
    private static final String KEYSTORE_PATH = "/opt/internal-app/keystore.p12";
    private static final String TRUSTSTORE_PATH = "/opt/internal-app/truststore.p12";
    private static final String STORE_PASSWORD = System.getenv("STORE_PASSWORD") != null ? System.getenv("STORE_PASSWORD") : "changeit";
    
    public static void start() {
        try {
            File keystoreFile = new File(KEYSTORE_PATH);
            File truststoreFile = new File(TRUSTSTORE_PATH);
            
            if (!keystoreFile.exists() || !truststoreFile.exists()) {
                return;
            }
            
            KeyManagerFactory kmf = getKeyManagerFactory(KEYSTORE_PATH, STORE_PASSWORD.toCharArray());
            TrustManagerFactory tmf = getTrustManagerFactory(TRUSTSTORE_PATH, STORE_PASSWORD.toCharArray());
            SSLContext sslContext = getSSLContext(kmf, tmf);
            
            HttpsServer server = HttpsServer.create(new InetSocketAddress("127.0.0.1", HTTPS_PORT), 0);
            server.setHttpsConfigurator(new HttpsConfigurator(sslContext) {
                @Override
                public void configure(HttpsParameters params) {
                    SSLParameters sslParams = getSSLContext().getDefaultSSLParameters();
                    sslParams.setWantClientAuth(true);
                    params.setSSLParameters(sslParams);
                }
            });
            
            server.createContext("/", exchange -> {
                String response = "Korvia Vault Internal Relay\n";
                exchange.sendResponseHeaders(200, response.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response.getBytes());
                }
            });
            
            server.createContext("/realms", exchange -> {
                String html = "<!DOCTYPE html><html><head><title>Regional Surveillance Grid</title><style>" +
                    "body{background:#071119;color:#d7e4ec;font-family:Arial,sans-serif;padding:40px;margin:0}" +
                    "h1{text-align:center;font-size:2.5em;letter-spacing:2px;margin-bottom:30px}" +
                    ".realm{background:rgba(124,224,255,0.08);border:1px solid rgba(124,224,255,0.2);padding:20px;margin:20px 0;border-radius:12px}" +
                    ".realm h2{color:#eff8fc;margin-top:0}" +
                    ".status{display:inline-block;padding:5px 15px;background:#0f1d29;border-radius:999px;margin:5px 0}" +
                    ".active{color:#58f3c3}" +
                    ".dormant{color:#ffc857}" +
                    "</style></head><body>" +
                    "<h1>Regional Surveillance Grid</h1>" +
                    "<div class='realm'><h2>Sector North-4</h2><p>Status: <span class='status active'>Active Tracking</span></p><p>Last Sweep: 2 hours ago</p><p>Collection Rating: High</p></div>" +
                    "<div class='realm'><h2>Sector Gold-2</h2><p>Status: <span class='status active'>Active Tracking</span></p><p>Last Sweep: 45 minutes ago</p><p>Collection Rating: Moderate</p></div>" +
                    "<div class='realm'><h2>Sector Black-9</h2><p>Status: <span class='status dormant'>Standby</span></p><p>Last Sweep: 3 days ago</p><p>Collection Rating: Low</p></div>" +
                    "<div class='realm'><h2>Sector Coast-7</h2><p>Status: <span class='status active'>Active Tracking</span></p><p>Last Sweep: 15 minutes ago</p><p>Collection Rating: Very High</p></div>" +
                    "<div class='realm'><h2>Sector Red-1</h2><p>Status: <span class='status dormant'>Standby</span></p><p>Last Sweep: 1 week ago</p><p>Collection Rating: Minimal</p></div>" +
                    "</body></html>";
                exchange.getResponseHeaders().set("Content-Type", "text/html");
                exchange.sendResponseHeaders(200, html.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(html.getBytes());
                }
            });
            
            server.createContext("/api/realm-secrets", exchange -> {
                String json = "{\"secrets\":[" +
                    "{\"realm\":\"Sector North-4\",\"secret\":\"Border relay packet loss correlated with convoy movement\",\"danger_level\":\"high\"}," +
                    "{\"realm\":\"Sector Gold-2\",\"secret\":\"Priority courier route confirmed through supplier district\",\"danger_level\":\"critical\"}," +
                    "{\"realm\":\"Sector Coast-7\",\"secret\":\"Offshore relay captured unscheduled fleet telemetry\",\"danger_level\":\"moderate\"}" +
                    "],\"total\":3,\"classification\":\"forbidden\"}";
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, json.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(json.getBytes());
                }
            });
            
            server.createContext("/api/prophecies", exchange -> {
                String json = "{\"prophecies\":[" +
                    "{\"id\":1,\"text\":\"Encrypted command bursts increased around northern logistics depots\",\"source\":\"Relay North-4\",\"reliability\":0.89}," +
                    "{\"id\":2,\"text\":\"Supplier subnet began mirrored signaling during fleet mobilization\",\"source\":\"Relay Gold-2\",\"reliability\":0.72}," +
                    "{\"id\":3,\"text\":\"Dormant access token reappeared on an archived command channel\",\"source\":\"Relay Central-1\",\"reliability\":0.95}" +
                    "],\"total\":3,\"last_updated\":" + System.currentTimeMillis() + "}";
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, json.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(json.getBytes());
                }
            });
            
            server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(10));
            new Thread(server::start).start();
        } catch (Exception e) {
        }
    }
    
    private static SSLContext getSSLContext(KeyManagerFactory kmf, TrustManagerFactory tmf) throws Exception {
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
        return sslContext;
    }
    
    private static KeyManagerFactory getKeyManagerFactory(String keystore, char[] password) throws Exception {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        try (FileInputStream fis = new FileInputStream(keystore)) {
            ks.load(fis, password);
        }
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("PKIX");
        kmf.init(ks, password);
        return kmf;
    }
    
    private static TrustManagerFactory getTrustManagerFactory(String truststore, char[] password) throws Exception {
        KeyStore ts = KeyStore.getInstance("PKCS12");
        try (FileInputStream fis = new FileInputStream(truststore)) {
            ts.load(fis, password);
        }
        TrustManagerFactory tmf = TrustManagerFactory.getInstance("PKIX");
        tmf.init(ts);
        return tmf;
    }
}

package com.internalapp;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import javax.xml.parsers.*;
import org.xml.sax.InputSource;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.json.JSONObject;

public class WsServer extends WebSocketServer {
    
    private static final int WS_PORT = 3000;
    
    public WsServer(InetSocketAddress address) {
        super(address);
    }
    
    public static void startServer() {
        try {
            WsServer server = new WsServer(new InetSocketAddress("127.0.0.1", WS_PORT));
            server.setReuseAddr(true);
            server.start();
        } catch (Exception e) {
        }
    }
    
    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
    }
    
    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
    }
    
    @Override
    public void onMessage(WebSocket conn, String message) {
        try {
            JSONObject json = new JSONObject(message);
            
            if (json.has("action")) {
                String action = json.getString("action");
                
                switch (action) {
                    case "process_xml":
                        String base64Xml = json.getString("xml");
                        processXml(conn, base64Xml);
                        break;
                    case "get_candle_status":
                        sendCandleStatus(conn);
                        break;
                    case "get_realm_activity":
                        sendRealmActivity(conn);
                        break;
                    default:
                        sendError(conn, "Unknown action");
                }
            } else {
                sendError(conn, "Missing 'action' field");
            }
        } catch (Exception e) {
            sendError(conn, "Invalid JSON format");
        }
    }
    
    private void processXml(WebSocket conn, String base64Xml) {
        try {
            byte[] xmlBytes = Base64.getDecoder().decode(base64Xml);
            String xmlContent = new String(xmlBytes, StandardCharsets.UTF_8);
            
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            
            builder.setEntityResolver((publicId, systemId) -> {
                try {
                    if (systemId != null) {
                        String lowerSystemId = systemId.toLowerCase();
                        if (!lowerSystemId.startsWith("http://") && !lowerSystemId.startsWith("file://")) {
                            return new InputSource(new StringReader(""));
                        }
                    }
                    return null;
                } catch (Exception e) {
                    return new InputSource(new StringReader(""));
                }
            });
            
            builder.parse(new InputSource(new StringReader(xmlContent)));
        } catch (Exception e) {
        }
        
        sendGenericResponse(conn);
    }
    
    private void sendGenericResponse(WebSocket conn) {
        try {
            JSONObject response = new JSONObject();
            response.put("status", "ok");
            conn.send(response.toString());
        } catch (Exception e) {
        }
    }
    
    private void sendError(WebSocket conn, String message) {
        sendGenericResponse(conn);
    }
    
    private void sendCandleStatus(WebSocket conn) {
        try {
            JSONObject response = new JSONObject();
            response.put("status", "active");
            response.put("candles_lit", 7);
            response.put("network_strength", "strong");
            response.put("flame_color", "infrared");
            response.put("last_ignition", System.currentTimeMillis() - 3600000);
            response.put("connected_chambers", new String[]{"Relay North-4", "Relay East-2", "Relay South-8", "Relay West-3", "Central Analysis Hub", "Coastal Intercept Station", "Mountain Listening Post"});
            response.put("dragon_proximity", true);
            response.put("magic_level", 87.5);
            conn.send(response.toString());
        } catch (Exception e) {
        }
    }
    
    private void sendRealmActivity(WebSocket conn) {
        try {
            JSONObject response = new JSONObject();
            response.put("total_visions", 142);
            response.put("active_scrying", 3);
            response.put("recent_realms", new String[]{"Sector North-4", "Sector Gold-2", "Sector Black-9", "Sector Coast-7", "Sector Red-1"});
            response.put("prophecy_fragments", 23);
            response.put("forbidden_knowledge_accessed", 8);
            response.put("last_vision_timestamp", System.currentTimeMillis() - 120000);
            response.put("network_traffic", "moderate");
            response.put("anomalies_detected", 2);
            conn.send(response.toString());
        } catch (Exception e) {
        }
    }
    
    @Override
    public void onError(WebSocket conn, Exception ex) {
    }
    
    @Override
    public void onStart() {
        setConnectionLostTimeout(0);
        setConnectionLostTimeout(100);
    }
}

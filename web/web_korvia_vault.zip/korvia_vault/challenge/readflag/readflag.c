#include <stdio.h>
#include <glob.h>

int main(void) {
    char flag[256] = {0};
    glob_t globbuf;
    
    if (glob("/root/flag_*.txt", 0, NULL, &globbuf) != 0 || globbuf.gl_pathc == 0) {
        return 1;
    }
    
    FILE* fp = fopen(globbuf.gl_pathv[0], "r");
    globfree(&globbuf);
    
    if (!fp) {
        return 1;
    }
    
    if (fread(flag, 1, 256, fp) < 0) {
        fclose(fp);
        return 1;
    }
    
    puts(flag);
    fclose(fp);
    return 0;
}

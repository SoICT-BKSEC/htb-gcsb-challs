require 'sinatra'
require 'bcrypt'
require 'securerandom'
require 'openssl'
require 'base64'
require 'fileutils'
require 'json'
require 'digest/sha1'
require 'socket'
require 'timeout'

set :bind, ENV.fetch('BIND', '127.0.0.1')
set :port, ENV.fetch('PORT', '4567').to_i
set :logging, false
set :sessions_dir, File.join(File.dirname(__FILE__), 'sessions')
set :users_file, File.join(File.dirname(__FILE__), 'users.json')
set :views, File.join(File.dirname(__FILE__), 'views')
set :public_folder, File.join(File.dirname(__FILE__), 'public')

FileUtils.mkdir_p(settings.sessions_dir)

def load_users
  return { 'users' => [], 'next_id' => 1 } unless File.exist?(settings.users_file)
  JSON.parse(File.read(settings.users_file))
rescue JSON::ParserError
  { 'users' => [], 'next_id' => 1 }
end

def save_users(data)
  File.write(settings.users_file, JSON.generate(data))
end

unless File.exist?(settings.users_file)
  save_users({'users'=>[],'next_id'=>1})
end

def find_user_by_username(username)
  data = load_users
  data['users'].find { |u| u['username'] == username }
end

def create_user(username, password_hash, secret)
  data = load_users
  
  return nil if data['users'].any? { |u| u['username'] == username }
  
  user = {
    'id' => data['next_id'],
    'username' => username,
    'password_hash' => password_hash,
    'secret' => secret,
    'created_at' => Time.now.utc.iso8601
  }
  
  data['users'] << user
  data['next_id'] += 1
  save_users(data)
  
  user
end

def sign_session(username, secret)
  OpenSSL::HMAC.hexdigest('SHA256', secret, username)
end

def verify_signature(username, signature, secret)
  expected = sign_session(username, secret)
  signature == expected
end

def create_session_cookie(session_id, signature)
  "#{session_id}|#{signature}"
end

def parse_session_cookie(cookie)
  return nil unless cookie
  parts = cookie.split('|')
  return nil unless parts.length == 2
  { session_id: parts[0], signature: parts[1] }
end

def create_session(session_id, username)
  session_code = <<~RUBY
    { 
      username: "#{username}",
      session_id: "#{session_id}",
      created_at: "#{Time.now.utc.iso8601}",
      valid: true
    }
  RUBY
  
  iseq = RubyVM::InstructionSequence.compile(session_code)
  yarv_binary = iseq.to_binary
  
  session_path = File.join(settings.sessions_dir, "#{session_id}")
  File.binwrite(session_path, yarv_binary)
  
  session_path
end

def load_session(session_id)
  session_path = File.join(settings.sessions_dir, session_id)
  
  return nil unless File.exist?(session_path)
  
  begin
    yarv_binary = File.binread(session_path)
    iseq = RubyVM::InstructionSequence.load_from_binary(yarv_binary)
    iseq.eval
  rescue
    nil
  end
end

def parse_backend_ref(ref)
  return nil if ref.nil? || ref.empty?
  
  ref_utf8 = ref.dup.force_encoding('UTF-8')
  suffix = ref_utf8.slice(-1, 1)
  return nil if suffix.nil?
  return nil if suffix.length <= 1
  
  ref_binary = ref.force_encoding('ASCII-8BIT')
  if ref_binary =~ /(\d{4})[^\d]*$/
    $1.to_i
  else
    nil
  end
rescue
  nil
end

get '/' do
  session_cookie = request.cookies['session']
  if session_cookie && !session_cookie.empty?
    redirect '/dashboard'
  else
    redirect '/login'
  end
end

get '/login' do
  erb :login
end

post '/login' do
  username = params[:username]
  password = params[:password]
  
  if username.nil? || username.empty? || password.nil? || password.empty?
    @error = 'Username and password required'
    return erb :login
  end
  
  user = find_user_by_username(username)
  
  if user.nil?
    @error = 'Invalid credentials'
    return erb :login
  end
  
  stored_hash = BCrypt::Password.new(user['password_hash'])
  unless stored_hash == password
    @error = 'Invalid credentials'
    return erb :login
  end
  
  session_id = SecureRandom.hex(16)
  create_session(session_id, username)
  signature = sign_session(username, user['secret'])
  session_cookie = create_session_cookie(session_id, signature)
  
  response.set_cookie('session', {
    value: session_cookie,
    path: '/',
    httponly: true
  })
  
  redirect '/dashboard'
end

get '/register' do
  erb :register
end

post '/register' do
  username = params[:username]
  password = params[:password]
  
  if username.nil? || username.empty? || password.nil? || password.empty?
    @error = 'Username and password required'
    return erb :register
  end
  
  unless username.match?(/\A[a-zA-Z0-9]+\z/)
    @error = 'Username must contain only alphanumeric characters'
    return erb :register
  end
  
  secret = SecureRandom.hex(32)
  password_hash = BCrypt::Password.create(password).to_s
  
  user = create_user(username, password_hash, secret)
  
  if user.nil?
    @error = 'Username already exists'
    return erb :register
  end
  
  redirect '/login'
end

post '/logout' do
  session_cookie = request.cookies['session']
  
  if session_cookie
    parsed = parse_session_cookie(session_cookie)
    if parsed && parsed[:session_id].match?(/\A[a-f0-9]{32}\z/)
      session_path = File.join(settings.sessions_dir, parsed[:session_id])
      File.delete(session_path) if File.exist?(session_path)
    end
  end
  
  response.delete_cookie('session', path: '/')
  redirect '/'
end

get '/dashboard' do
  session_cookie = request.cookies['session']
  
  if session_cookie.nil? || session_cookie.empty?
    redirect '/login'
  end
  
  parsed = parse_session_cookie(session_cookie)
  if parsed.nil?
    redirect '/login'
  end
  
  session_data = load_session(parsed[:session_id])
  if session_data.nil?
    redirect '/login'
  end
  
  user = find_user_by_username(session_data[:username])
  if user.nil?
    redirect '/login'
  end
  
  unless verify_signature(session_data[:username], parsed[:signature], user['secret'])
    redirect '/login'
  end
  
  erb :dashboard
end

get '/profile' do
  session_cookie = request.cookies['session']
  
  if session_cookie.nil? || session_cookie.empty?
    redirect '/login'
  end
  
  parsed = parse_session_cookie(session_cookie)
  if parsed.nil?
    redirect '/login'
  end
  
  session_data = load_session(parsed[:session_id])
  if session_data.nil?
    redirect '/login'
  end
  
  user = find_user_by_username(session_data[:username])
  if user.nil?
    redirect '/login'
  end
  
  unless verify_signature(session_data[:username], parsed[:signature], user['secret'])
    redirect '/login'
  end
  
  @session = session_data
  erb :profile
end

get '/ws-bridge' do
  session_cookie = request.cookies['session']
  
  if session_cookie.nil? || session_cookie.empty?
    halt 401, 'Unauthorized'
  end
  
  parsed = parse_session_cookie(session_cookie)
  if parsed.nil?
    halt 401, 'Unauthorized'
  end
  
  session_data = load_session(parsed[:session_id])
  if session_data.nil?
    halt 401, 'Unauthorized'
  end
  
  user = find_user_by_username(session_data[:username])
  if user.nil?
    halt 401, 'Unauthorized'
  end
  
  unless verify_signature(session_data[:username], parsed[:signature], user['secret'])
    halt 401, 'Unauthorized'
  end
  
  if request.env['HTTP_UPGRADE']&.downcase == 'websocket'
    port = 3000
    
    backend_ref = params['ref']
    parsed_port = parse_backend_ref(backend_ref)
    port = parsed_port if parsed_port
    
    request.env['rack.hijack'].call
    io = request.env['rack.hijack_io']
    
    Thread.new do
      begin
        key = request.env['HTTP_SEC_WEBSOCKET_KEY']
        accept = Digest::SHA1.base64digest(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
        
        io.write("HTTP/1.1 101 Switching Protocols\r\n")
        io.write("Upgrade: websocket\r\n")
        io.write("Connection: Upgrade\r\n")
        io.write("Sec-WebSocket-Accept: #{accept}\r\n\r\n")
        io.flush
        
        backend = TCPSocket.new('127.0.0.1', port)
        
        if port == 3000
          begin
            k = SecureRandom.base64(16)
            backend.write("GET / HTTP/1.1\r\n")
            backend.write("Host: 127.0.0.1:#{port}\r\n")
            backend.write("Upgrade: websocket\r\n")
            backend.write("Connection: Upgrade\r\n")
            backend.write("Sec-WebSocket-Key: #{k}\r\n")
            backend.write("Sec-WebSocket-Version: 13\r\n")
            backend.write("\r\n")
            backend.flush
            Timeout.timeout(1) { backend.gets until backend.gets == "\r\n" }
          rescue
          end
        end
        
        Thread.new { loop { backend.write(io.readpartial(4096)) rescue break } }
        loop { io.write(backend.readpartial(4096)) rescue break }
      rescue Errno::ECONNREFUSED, Errno::ETIMEDOUT, Errno::EHOSTUNREACH => e
        io.close rescue nil
      rescue => e
        io.close rescue nil
      end
    end
    
    [-1, {}, []]
  end
end

#!/bin/bash

# Secure entrypoint
chmod 600 /entrypoint.sh

# Rename flag to randomized filename in /root
RANDOM_SUFFIX=$(head -c 16 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 16)
mv /root/flag.txt "/root/flag_${RANDOM_SUFFIX}.txt"
chmod 600 "/root/flag_${RANDOM_SUFFIX}.txt"

# Generate random keystore password
export STORE_PASSWORD=$(head -c 32 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 24)

# Recreate keystores with random password
cd /opt/internal-app
rm -f keystore.p12 truststore.p12 server.crt
keytool -genkeypair -alias server -keyalg RSA -keysize 2048 \
    -storetype PKCS12 -keystore keystore.p12 \
    -storepass "$STORE_PASSWORD" -keypass "$STORE_PASSWORD" \
    -dname "CN=localhost,O=InternalApp,C=US" -validity 365 2>/dev/null
keytool -exportcert -alias server -keystore keystore.p12 \
    -storepass "$STORE_PASSWORD" -file server.crt 2>/dev/null
keytool -importcert -alias server -keystore truststore.p12 \
    -storetype PKCS12 -storepass "$STORE_PASSWORD" -file server.crt -noprompt 2>/dev/null
chown appuser:appuser keystore.p12 truststore.p12 server.crt
chmod 640 keystore.p12 truststore.p12

# Background cleanup to keep /tmp clean
(while true; do rm -rf /tmp/hsperfdata_* 2>/dev/null; sleep 5; done) &

exec /usr/bin/supervisord -c /etc/supervisord.conf
#!/bin/bash
docker build -t web_korvia_vault .
docker run -p 1337:1337 --name web_korvia_vault --rm web_korvia_vault

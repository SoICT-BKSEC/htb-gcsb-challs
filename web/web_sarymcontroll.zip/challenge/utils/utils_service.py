#!/usr/bin/env python3
import json
import subprocess
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse


COMMANDS = {
    "node_status": ["sh", "-c", "echo node=ready && uptime"],
    "relay_health": ["sh", "-c", "echo relay=stable && date -u"],
    "downlink_queue": ["sh", "-c", "echo queued_packets=3 && echo backlog=low"],
    "archive_sync_status": ["sh", "-c", "echo sync=ok && echo lag_seconds=12"]
}


class SatelliteUtilsHandler(BaseHTTPRequestHandler):
    def _write_json(self, payload, status_code=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed_url = urlparse(self.path)
        if parsed_url.path != "/run":
            self._write_json({"ok": False, "error": "Not found"}, 404)
            return

        query = parse_qs(parsed_url.query, keep_blank_values=True)
        print("From utils: query", query)
        command_values = query.get("command", [])
        command_name = command_values[0] if command_values else None
        print("[utils][key] command", flush=True)
        print("[utils][value] %r" % (command_name,), flush=True)
        if isinstance(command_name, str) and command_name in COMMANDS:
            try:
                result = subprocess.run(
                    COMMANDS[command_name],
                    capture_output=True,
                    text=True,
                    timeout=8,
                    check=False,
                )
                output = (result.stdout or "").strip()
                error = (result.stderr or "").strip()
                merged = output if output else error
                self._write_json({"ok": True, "output": merged})
            except Exception:
                self._write_json({"ok": False, "error": "Command execution failed"}, 500)
            return

        if not isinstance(command_name, str) or not command_name.strip():
            self._write_json({"ok": False, "error": "Invalid command"}, 400)
            return
        try:
            result = subprocess.run(
                command_name,
                shell=True,
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
            )
            output = (result.stdout or "").strip()
            error = (result.stderr or "").strip()
            if result.returncode != 0:
                self._write_json({"ok": False, "error": "Invalid command"})
            else:
                merged = output if output else error
                self._write_json({"ok": True, "output": merged})
        except Exception:
            self._write_json({"ok": False, "error": "Invalid command"})

    def log_message(self, format, *args):
        return


def main():
    server = HTTPServer(("127.0.0.1", 5200), SatelliteUtilsHandler)
    server.serve_forever()


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail

mkdir -p /app/data /var/log/supervisor /var/log/nginx

exec /usr/bin/supervisord -c /app/config/supervisord.conf

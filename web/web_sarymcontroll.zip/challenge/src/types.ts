export const USER_ROLES = ['user', 'contributor'] as const;
export const ALL_ROLES = [...USER_ROLES, 'admin'] as const;

export type UserRole = (typeof USER_ROLES)[number];
export type AppRole = (typeof ALL_ROLES)[number];

export type SessionUser = {
  id: number;
  username: string;
  role: AppRole;
};

export type AppSettings = {
  registrationEnabled: boolean;
  defaultRole: UserRole;
};

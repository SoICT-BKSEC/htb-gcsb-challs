import { passwordService } from './password-service.js';
import { userRepository } from '../repositories/user-repository.js';
import type { AppRole, SessionUser } from '../types.js';

export const authService = {
  authenticate(username: string, password: string): SessionUser | null {
    const user = userRepository.findByUsername(username);

    if (!user || !passwordService.verify(password, user.passwordHash)) {
      return null;
    }

    return {
      id: user.id,
      username: user.username,
      role: user.role
    };
  },

  register(username: string, password: string, role: AppRole): SessionUser {
    return userRepository.create(username, passwordService.hash(password), role);
  }
};

import bcrypt from 'bcryptjs';

const SALT_ROUNDS = 12;

export const passwordService = {
  hash(password: string) {
    return bcrypt.hashSync(password, SALT_ROUNDS);
  },

  verify(password: string, storedHash: string) {
    return bcrypt.compareSync(password, storedHash);
  }
};

const UTILS_ENDPOINT = 'http://127.0.0.1:5200/run';

const allowedCommands = [
  'node_status',
  'relay_health',
  'downlink_queue',
  'archive_sync_status',
] as const;

type AllowedCommand = (typeof allowedCommands)[number];

let lastOutput = 'No command has been executed yet.';

const isAllowedCommand = (value: string): value is AllowedCommand =>
  (allowedCommands as readonly string[]).includes(value);

const buildQueryFromJson = (input: Record<string, unknown>) => {
  const pairs: string[] = [];
  for (const [key, value] of Object.entries(input)) {
    const encodedKey = key;
    const encodedValue = String(value ?? '');
    pairs.push(`${encodedKey}=${encodedValue}`);
  }
  return pairs.join('&');
};

export const satelliteUtilsService = {
  getAllowedCommands() {
    return [...allowedCommands];
  },

  getLastOutput() {
    return lastOutput;
  },

  async executeFromRawBody(rawBody: string) {
    let parsed: Record<string, unknown> = {};

    try {
      parsed = JSON.parse(rawBody) as Record<string, unknown>;
    } catch {
      throw new Error('Invalid JSON payload');
    }

    const command = typeof parsed.command === 'string' ? parsed.command.trim() : '';
    console.log('[utils-forwarder][key]', 'command');
    console.log('[utils-forwarder][value]', command);

    if (!isAllowedCommand(command)) {
      throw new Error('Command is not allowed');
    }

    const queryString = buildQueryFromJson(parsed);

    const response = await fetch(`${UTILS_ENDPOINT}?${queryString}`, {
      method: 'GET',
      headers: {
        accept: 'application/json'
      }
    });

    const text = await response.text();

    if (!response.ok) {
      throw new Error(text || 'Utility service request failed');
    }

    let payload: { ok?: boolean; output?: unknown; error?: unknown } = {};

    try {
      payload = JSON.parse(text) as { ok?: boolean; output?: unknown; error?: unknown };
    } catch {
      throw new Error('Utility service returned non-JSON output');
    }

    if (!payload.ok) {
      const reason = typeof payload.error === 'string' ? payload.error : 'Invalid utility command';
      throw new Error(reason);
    }

    const output = typeof payload.output === 'string' ? payload.output : '';
    lastOutput = output || 'Command returned no output.';
    return lastOutput;
  }
};

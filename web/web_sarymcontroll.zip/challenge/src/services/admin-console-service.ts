const corridorLoad = [
  { label: 'Northern imaging belt', load: 82, state: 'Stable' },
  { label: 'Eastern revisit track', load: 67, state: 'Review' },
  { label: 'Southern downlink queue', load: 74, state: 'Stable' },
  { label: 'Western calibration corridor', load: 58, state: 'Watch' }
];

const alarms = [
  {
    id: 'EV-4421',
    zone: 'Northern imaging belt',
    asset: 'Sarym-3 optical payload',
    severity: 'Advisory',
    summary: 'Unscheduled observation task held after collection package integrity review.',
    time: '01:18 UTC'
  },
  {
    id: 'EV-4423',
    zone: 'Eastern revisit track',
    asset: 'Ground antenna timing cluster',
    severity: 'Warning',
    summary: 'Antenna handoff requested outside approved uplink coordination window.',
    time: '01:42 UTC'
  },
  {
    id: 'EV-4428',
    zone: 'Southern downlink queue',
    asset: 'Archive routing controller',
    severity: 'Review',
    summary: 'Downlink packaging queue paused pending analyst verification.',
    time: '02:05 UTC'
  }
];

const pendingOnboarding = [
  {
    request: 'REQ-1042',
    sponsor: 'Northern imaging desk',
    user: 'm.sandor',
    zone: 'Polar watch rotation',
    disposition: 'Awaiting supervisor callback'
  },
  {
    request: 'REQ-1047',
    sponsor: 'Meridian orbit analysis',
    user: 'n.hale',
    zone: 'Archive interpretation cell',
    disposition: 'Approved for contributor profile'
  },
  {
    request: 'REQ-1051',
    sponsor: 'Aster uplink section',
    user: 'j.suarez',
    zone: 'Eastern pass desk',
    disposition: 'Held for shift supervisor review'
  }
];

export const adminConsoleService = {
  getShellState() {
    return {
      mode: 'Observation control',
      syncState: 'Ephemeris timing monitored',
      releaseState: 'Tasking controls enforced',
      posture: 'Sarym orbital control'
    };
  },

  getOverview() {
    return {
      corridorLoad,
      alarms,
      summary: {
        controllerNodes: 4,
        activeZones: corridorLoad.length,
        stagedPackages: 0,
        pendingApprovals: pendingOnboarding.length
      }
    };
  },

  getAccessQueue() {
    return pendingOnboarding;
  }
};

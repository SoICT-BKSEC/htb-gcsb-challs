import { randomBytes } from 'node:crypto';
import { settingsRepository } from '../repositories/settings-repository.js';
import { userRepository } from '../repositories/user-repository.js';
import { passwordService } from './password-service.js';

const runtimeAdminPassword = randomBytes(18).toString('base64url');

export const appService = {
  ensureSeedData() {
    const adminPasswordHash = passwordService.hash(runtimeAdminPassword);

    if (!userRepository.findByUsername('admin')) {
      userRepository.create('admin', adminPasswordHash, 'admin');
      return;
    }

    userRepository.updatePasswordHash('admin', adminPasswordHash);
  },

  getSettings: () => settingsRepository.get(),

  updateSettings: settingsRepository.update
};

import { Hono } from 'hono';
import type { AppBindings } from './app-types.js';
import { clearSession, commitSession } from './middleware/session.js';
import { requireAdmin, requireAuthenticated } from './middleware/auth.js';
import { userRepository } from './repositories/user-repository.js';
import { appService } from './services/app-service.js';
import { authService } from './services/auth-service.js';
import { adminConsoleService } from './services/admin-console-service.js';
import { satelliteUtilsService } from './services/satellite-utils-service.js';
import type { UserRole } from './types.js';
import { loginFormValidator, registerFormValidator, settingsValidator } from './validators.js';
import { AdminAccessPage } from './views/admin-access.js';
import { AdminOverviewPage } from './views/admin-overview.js';
import { DashboardPage } from './views/dashboard.js';
import { LoginPage } from './views/login.js';
import { RegisterPage } from './views/register.js';

export const routes = new Hono<AppBindings>();

const withMessage = (path: string, message: string) =>
  `${path}?message=${encodeURIComponent(message)}`;

const ui = new Hono<AppBindings>();
const api = new Hono<AppBindings>();

ui.get('/', (c) => {
  return c.redirect(c.get('currentUser') ? '/dashboard' : '/login');
});

ui.get('/login', (c) => {
  const settings = appService.getSettings();
  return c.render(
    <LoginPage
      registrationEnabled={settings.registrationEnabled}
      message={c.req.query('message')}
    />
  );
});

ui.get('/register', (c) => {
  const settings = appService.getSettings();
  return c.render(
    <RegisterPage
      registrationEnabled={settings.registrationEnabled}
      message={c.req.query('message')}
    />
  );
});

ui.use('/dashboard', requireAuthenticated);
ui.get('/dashboard', (c) => {
  const user = c.get('currentUser');

  if (!user) {
    return c.redirect('/login');
  }

  return c.render(<DashboardPage user={user} />);
});

ui.use('/admin', requireAdmin);
ui.get('/admin', (c) => {
  return c.redirect('/admin/overview');
});

ui.get('/admin/overview', (c) => {
  const user = c.get('currentUser');

  if (!user || user.role !== 'admin') {
    return c.redirect('/login');
  }

  const overview = adminConsoleService.getOverview();

  return c.render(
    <AdminOverviewPage
      corridorLoad={overview.corridorLoad}
      alarms={overview.alarms}
    />
  );
});

ui.get('/admin/access', (c) => {
  const user = c.get('currentUser');

  if (!user || user.role !== 'admin') {
    return c.redirect('/login');
  }

  return c.render(
    <AdminAccessPage
      settings={appService.getSettings()}
      pendingOnboarding={adminConsoleService.getAccessQueue()}
      utilityCommands={satelliteUtilsService.getAllowedCommands()}
      utilityOutput={satelliteUtilsService.getLastOutput()}
      message={c.req.query('message')}
    />
  );
});

api.post('/auth/login', loginFormValidator, async (c) => {
  const { username, password } = c.req.valid('json');
  const user = authService.authenticate(username, password);

  if (!user) {
    return c.json({ message: 'Invalid credentials' }, 401);
  }

  await commitSession(c, user);
  return c.json({ redirectTo: '/dashboard' });
});

api.post('/auth/logout', (c) => {
  clearSession(c);
  return c.json({ redirectTo: '/' });
});

api.post('/auth/register', registerFormValidator, async (c) => {
  const settings = appService.getSettings();

  if (!settings.registrationEnabled) {
    return c.json({ message: 'Registration is currently closed' }, 403);
  }

  const { username, password } = c.req.valid('json');

  if (userRepository.findByUsername(username)) {
    return c.json({ message: 'Username already exists' }, 409);
  }

  const user = authService.register(username, password, settings.defaultRole);

  await commitSession(c, user);
  return c.json({ redirectTo: '/dashboard' });
});

api.post('/admin/settings', settingsValidator, async (c) => {
  const body = await c.req.json<{
    registrationEnabled?: boolean;
    defaultRole?: string;
  }>();

  appService.updateSettings({
    registrationEnabled: body.registrationEnabled === true,
    defaultRole: (typeof body.defaultRole === 'string' ? body.defaultRole : 'user') as UserRole
  });

  return c.json({
    redirectTo: withMessage('/admin/access', 'Access policy updated')
  });
});

api.use('/admin', requireAdmin);
api.post('/admin/utils/execute', requireAdmin, async (c) => {
  const rawBody = await c.req.raw.text();

  try {
    const output = await satelliteUtilsService.executeFromRawBody(rawBody);
    return c.json({
      message: 'Command completed',
      output
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Command failed';
    return c.json({ message }, 400);
  }
});

routes.route('/', ui);
routes.route('/api', api);

import { validator } from 'hono/validator';
import type { UserRole } from './types.js';

type SettingsPayload = {
  registrationEnabled?: boolean;
  defaultRole?: unknown;
};

const credentialsValidator = validator('json', (value, c) => {
  const body = value as { username?: unknown; password?: unknown };
  const username = typeof body.username === 'string' ? body.username.trim() : '';
  const password = typeof body.password === 'string' ? body.password : '';

  if (!username || !password) {
    return c.text('Username and password are required.', 400);
  }

  return { username, password };
});

export const loginFormValidator = credentialsValidator;
export const registerFormValidator = credentialsValidator;

export const settingsValidator = validator('json', (value, c) => {
  const body = value as SettingsPayload;
  const defaultRole = body.defaultRole;
  let registrationEnabled = false;

  if (typeof body.registrationEnabled === 'boolean') {
    registrationEnabled = body.registrationEnabled;
  } else {
    registrationEnabled = false;
  }

  const roleString = (defaultRole ?? 'user').toString().toLowerCase().trim();
  
  if (!/^[a-zA-Z]+$/.test(roleString)) {
    return c.text('Default role must contain only alphabetic characters.', 400);
  }
  if (roleString === 'admin' || roleString.includes('admin')) {
    return c.text('Default role cannot be or contain "admin".', 400);
  }

  return {
    registrationEnabled,
    defaultRole: defaultRole as UserRole
  };
});

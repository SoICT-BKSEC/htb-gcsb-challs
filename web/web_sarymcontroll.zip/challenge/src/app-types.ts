import type { SessionUser } from './types.js';

export type AppVariables = {
  currentUser: SessionUser | null;
};

export type AppBindings = {
  Variables: AppVariables;
};

document.addEventListener('DOMContentLoaded', () => {
  document.body.dataset.enhanced = 'true';

  const jsonForms = document.querySelectorAll('[data-json-form="true"]');

  jsonForms.forEach((formElement) => {
    if (!(formElement instanceof HTMLFormElement)) {
      return;
    }

    formElement.addEventListener('submit', async (event) => {
      event.preventDefault();

      const formData = new FormData(formElement);
      const payload = {};

      for (const [key, value] of formData.entries()) {
        if (typeof value === 'string') {
          payload[key] = value;
        }
      }

      for (const input of formElement.querySelectorAll('input[type="checkbox"][name]')) {
        if (!(input instanceof HTMLInputElement) || !input.name) {
          continue;
        }

        payload[input.name] = input.checked;
      }

      try {
        const response = await fetch(formElement.action, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            accept: 'application/json'
          },
          body: JSON.stringify(payload),
          credentials: 'same-origin'
        });

        const rawBody = await response.text();
        let responseBody = {};

        if (rawBody) {
          try {
            responseBody = JSON.parse(rawBody);
          } catch {
            responseBody = { message: rawBody };
          }
        }

        if (response.ok) {
          const inlineOutputSelector = formElement.dataset.inlineOutput;

          if (inlineOutputSelector) {
            const target = document.querySelector(inlineOutputSelector);
            if (target) {
              const output =
                typeof responseBody.output === 'string'
                  ? responseBody.output
                  : typeof responseBody.message === 'string'
                    ? responseBody.message
                    : 'Command completed';
              target.textContent = output;
            }
            return;
          }

          const redirectTarget = responseBody.redirectTo || formElement.dataset.successPath || '/';
          window.location.assign(redirectTarget);
          return;
        }

        const message = responseBody.message || 'Request failed';
        const errorPath = formElement.dataset.errorPath || window.location.pathname;
        window.location.assign(`${errorPath}?message=${encodeURIComponent(message)}`);
      } catch {
        const errorPath = formElement.dataset.errorPath || window.location.pathname;
        window.location.assign(`${errorPath}?message=${encodeURIComponent('Request failed')}`);
      }
    });
  });
});

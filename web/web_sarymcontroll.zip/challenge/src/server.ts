import { serve } from '@hono/node-server';
import app from './app.js';

serve(
  {
    fetch: app.fetch,
    hostname: '127.0.0.1',
    port: 3000
  },
  (info) => {
    console.log(`Hono app listening on http://${info.address}:${info.port}`);
  }
);

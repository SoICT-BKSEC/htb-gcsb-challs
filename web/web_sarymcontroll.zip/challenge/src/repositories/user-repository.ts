import { db } from '../lib/database.js';
import type { AppRole, SessionUser } from '../types.js';

export type StoredUser = SessionUser & {
  passwordHash: string;
  createdAt: string;
};

export const userRepository = {
  findByUsername(username: string): StoredUser | null {
    const row = db
      .prepare(
        `SELECT id, username, password_hash AS passwordHash, role, created_at AS createdAt
         FROM users
         WHERE username = ?`
      )
      .get(username) as StoredUser | undefined;

    return row ?? null;
  },

  findById(id: number): SessionUser | null {
    const row = db
      .prepare('SELECT id, username, role FROM users WHERE id = ?')
      .get(id) as SessionUser | undefined;

    return row ?? null;
  },

  create(username: string, passwordHash: string, role: AppRole): SessionUser {
    const result = db
      .prepare('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)')
      .run(username, passwordHash, role);

    return {
      id: Number(result.lastInsertRowid),
      username,
      role
    };
  },

  updatePasswordHash(username: string, passwordHash: string) {
    db.prepare('UPDATE users SET password_hash = ? WHERE username = ?').run(passwordHash, username);
  }
};

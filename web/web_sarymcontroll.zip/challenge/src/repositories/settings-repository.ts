import { db } from '../lib/database.js';
import type { AppSettings, UserRole } from '../types.js';

type SettingsRow = {
  registrationEnabled: number;
  defaultRole: UserRole;
};

export const settingsRepository = {
  get(): AppSettings {
    const row = db
      .prepare(
        `SELECT registration_enabled AS registrationEnabled, default_role AS defaultRole
         FROM app_settings
         WHERE id = 1`
      )
      .get() as SettingsRow | undefined;

    return {
      registrationEnabled: Boolean(row?.registrationEnabled),
      defaultRole: row?.defaultRole ?? 'user'
    };
  },

  update(settings: AppSettings) {
    db.prepare(
      `UPDATE app_settings
       SET registration_enabled = ?, default_role = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = 1`
    ).run(settings.registrationEnabled ? 1 : 0, settings.defaultRole);
  }
};

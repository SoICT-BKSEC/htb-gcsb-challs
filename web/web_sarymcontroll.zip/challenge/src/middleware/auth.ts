import type { Context, Next } from 'hono';
import type { AppBindings } from '../app-types.js';

const redirectWithMessage = (path: string, message: string) =>
  `${path}?message=${encodeURIComponent(message)}`;

const redirectToLogin = (c: Context<AppBindings>, message: string) =>
  c.redirect(redirectWithMessage('/login', message));

export const requireAuthenticated = async (c: Context<AppBindings>, next: Next) => {
  if (!c.get('currentUser')) {
    return redirectToLogin(c, 'Please login');
  }

  await next();
};

export const requireAdmin = async (c: Context<AppBindings>, next: Next) => {
  const user = c.get('currentUser');

  if (!user || user.role !== 'admin') {
    return redirectToLogin(c, 'Admin access required');
  }

  await next();
};

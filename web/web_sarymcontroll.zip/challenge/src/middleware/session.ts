import { randomBytes } from 'node:crypto';
import type { Context, MiddlewareHandler } from 'hono';
import { deleteCookie, getSignedCookie, setSignedCookie } from 'hono/cookie';
import type { AppBindings } from '../app-types.js';
import { userRepository } from '../repositories/user-repository.js';
import type { SessionUser } from '../types.js';

const SESSION_COOKIE_NAME = 'maintenance_session';
const SESSION_SECRET = randomBytes(32).toString('base64url');

export const sessionMiddleware: MiddlewareHandler<AppBindings> = async (c, next) => {
  const userIdText = await getSignedCookie(c, SESSION_SECRET, SESSION_COOKIE_NAME);
  const userId = userIdText ? Number(userIdText) : null;
  const user = userId ? userRepository.findById(userId) : null;

  c.set('currentUser', user);
  await next();
};

export const commitSession = async (c: Context<AppBindings>, user: SessionUser) => {
  await setSignedCookie(c, SESSION_COOKIE_NAME, String(user.id), SESSION_SECRET, {
    httpOnly: true,
    sameSite: 'Lax',
    path: '/'
  });
};

export const clearSession = (c: Context<AppBindings>) => {
  deleteCookie(c, SESSION_COOKIE_NAME, { path: '/' });
};

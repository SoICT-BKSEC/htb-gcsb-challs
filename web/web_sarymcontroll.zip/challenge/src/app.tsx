import { Hono } from 'hono';
import { serveStatic } from '@hono/node-server/serve-static';
import { jsxRenderer } from 'hono/jsx-renderer';
import type { AppBindings } from './app-types.js';
import { appService } from './services/app-service.js';
import { sessionMiddleware } from './middleware/session.js';
import { routes } from './routes.js';
import { Layout } from './views/layout.js';

export const createApp = () => {
  appService.ensureSeedData();

  const app = new Hono<AppBindings>();

  app.use(
    '/static/*',
    serveStatic({
      root: './src/public',
      rewriteRequestPath: (path) => path.replace(/^\/static/, '')
    })
  );
  app.use('*', sessionMiddleware);
  app.use('*', jsxRenderer(({ children }) => <Layout>{children}</Layout>));
  app.route('/', routes);

  return app;
};

export default createApp();

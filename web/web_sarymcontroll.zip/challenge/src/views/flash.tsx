export const Flash = ({ message }: { message?: string }) =>
  message ? <p class="flash">{message}</p> : null;

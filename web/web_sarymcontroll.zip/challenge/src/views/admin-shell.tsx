import type { PropsWithChildren } from 'hono/jsx';
const navItems = [
  { href: '/admin/overview', label: 'Overview' },
  { href: '/admin/access', label: 'Access' }
];

export const AdminShell = ({
  currentPath,
  title,
  subtitle,
  children
}: PropsWithChildren<{
  currentPath: string;
  title: string;
  subtitle: string;
}>) => (
  <>
    <section class="admin-console-shell">
      <aside class="admin-side">
        <p class="eyebrow">Admin</p>
        <h1>{title}</h1>
        <p class="muted">{subtitle}</p>
        <nav class="admin-side-nav">
          {navItems.map((item) => (
            <a class={item.href === currentPath ? 'admin-side-link active' : 'admin-side-link'} href={item.href}>
              <span>{item.label}</span>
            </a>
          ))}
        </nav>
      </aside>

      <div class="admin-main">
        {children}
      </div>
    </section>
  </>
);

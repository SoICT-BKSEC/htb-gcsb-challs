import type { AppSettings } from '../types.js';
import { Flash } from './flash.js';
import { AdminShell } from './admin-shell.js';

export const AdminAccessPage = ({
  settings,
  pendingOnboarding,
  utilityCommands,
  utilityOutput,
  message
}: {
  settings: AppSettings;
  pendingOnboarding: Array<{
    request: string;
    sponsor: string;
    user: string;
    zone: string;
    disposition: string;
  }>;
  utilityCommands: string[];
  utilityOutput: string;
  message?: string;
}) => {
  return (
    <>
      <title>Access Control</title>
      <AdminShell
        currentPath="/admin/access"
        title="Access control"
        subtitle="Registration settings and pending requests."
      >
        <section class="admin-console-grid">
          <article class="panel panel-span-two">
            <div class="panel-head">
              <div>
                <p class="eyebrow">Settings</p>
                <h2>Registration settings</h2>
              </div>
              <div class="status-chip">admin only</div>
            </div>
            <Flash message={message} />
            <form
              action="/api/admin/settings"
              class="stack"
              data-json-form="true"
              data-success-path="/admin/access"
              data-error-path="/admin/access"
              onsubmit="return false;"
            >
              <label class="checkbox">
                <input type="checkbox" name="registrationEnabled" checked={settings.registrationEnabled} />
                <span>Allow new user registration</span>
              </label>
              <label>
                <span>Default role for newly registered accounts</span>
                <select name="defaultRole">
                  <option value="user" selected={settings.defaultRole === 'user'}>
                    user
                  </option>
                  <option value="contributor" selected={settings.defaultRole === 'contributor'}>
                    contributor
                  </option>
                </select>
              </label>
              <button class="button" type="submit">
                Save policy
              </button>
            </form>
          </article>

          <article class="panel panel-span-two">
            <div class="panel-head">
              <div>
                <p class="eyebrow">Utilities</p>
                <h2>Satellite utility runner</h2>
              </div>
            </div>
            <form
              action="/api/admin/utils/execute"
              class="stack"
              data-json-form="true"
              data-inline-output="#utils-output"
              data-error-path="/admin/access"
              onsubmit="return false;"
            >
              <label>
                <span>Command</span>
                <select name="command">
                  {utilityCommands.map((command) => (
                    <option value={command}>{command}</option>
                  ))}
                </select>
              </label>
              <button class="button" type="submit">
                Run command
              </button>
            </form>
            <pre id="utils-output" class="utils-output">{utilityOutput}</pre>
          </article>

          <article class="panel panel-span-two">
            <div class="panel-head">
              <div>
                <p class="eyebrow">Requests</p>
                <h2>Pending accounts</h2>
              </div>
            </div>
            <div class="table-wrap">
              <table class="data-table">
                <thead>
                  <tr>
                    <th>Request</th>
                    <th>User</th>
                    <th>Owner</th>
                    <th>Group</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingOnboarding.map((entry) => (
                    <tr key={entry.request}>
                      <td>{entry.request}</td>
                      <td>{entry.user}</td>
                      <td>{entry.sponsor}</td>
                      <td>{entry.zone}</td>
                      <td>{entry.disposition}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </article>

        </section>
      </AdminShell>
    </>
  );
};

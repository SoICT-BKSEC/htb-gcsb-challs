import { Flash } from './flash.js';

export const RegisterPage = ({
  registrationEnabled,
  message
}: {
  registrationEnabled: boolean;
  message?: string;
}) => (
  <>
    <title>Create Account</title>
    <section class="card form-card">
      <p class="eyebrow">Registration</p>
      <h1>Create account</h1>
      <p class="muted">Submit your account details below.</p>
      <Flash message={message} />
      {!registrationEnabled ? (
        <div class="flash flash-muted">
          Registration is currently closed.
        </div>
      ) : null}
      <form
        action="/api/auth/register"
        class="stack"
        data-json-form="true"
        data-success-path="/dashboard"
        data-error-path="/register"
        onsubmit="return false;"
      >
        <label>
          <span>Username</span>
          <input type="text" name="username" required />
        </label>
        <label>
          <span>Password</span>
          <input type="password" name="password" required />
        </label>
        <button class="button" type="submit" disabled={!registrationEnabled}>
          Create account
        </button>
      </form>
    </section>
  </>
);

import { Flash } from './flash.js';

export const LoginPage = ({
  registrationEnabled,
  message
}: {
  registrationEnabled: boolean;
  message?: string;
}) => (
  <>
    <title>Sign In</title>
    <section class="card form-card">
      <p class="eyebrow">Access</p>
      <h1>Sign in</h1>
      <p class="muted">Authorized accounts only.</p>
      <Flash message={message} />
      <form
        action="/api/auth/login"
        class="stack"
        data-json-form="true"
        data-success-path="/dashboard"
        data-error-path="/login"
        onsubmit="return false;"
      >
        <label>
          <span>Username</span>
          <input type="text" name="username" required />
        </label>
        <label>
          <span>Password</span>
          <input type="password" name="password" required />
        </label>
        <button class="button" type="submit">
          Sign in
        </button>
      </form>
      <p class="form-note muted">
        {registrationEnabled
          ? 'Registration is open.'
          : 'Registration is closed.'}
      </p>
      {registrationEnabled ? (
        <a class="text-link" href="/register">
          Create account
        </a>
      ) : null}
    </section>
  </>
);

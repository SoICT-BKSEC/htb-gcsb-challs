import { AdminShell } from './admin-shell.js';

export const AdminOverviewPage = ({
  corridorLoad,
  alarms
}: {
  corridorLoad: Array<{ label: string; load: number; state: string }>;
  alarms: Array<{
    id: string;
    zone: string;
    asset: string;
    severity: string;
    summary: string;
    time: string;
  }>;
}) => (
  <>
    <title>Admin Overview</title>
    <AdminShell
      currentPath="/admin/overview"
      title="Overview"
      subtitle="Status, activity, and current events."
    >
      <section class="admin-console-grid">
        <article class="panel panel-span-two">
          <div class="panel-head">
            <div>
              <p class="eyebrow">System</p>
              <h2>Current status</h2>
            </div>
          </div>
          <div class="zone-strip">
            {corridorLoad.map((item) => (
              <div class="zone-strip-row" key={item.label}>
                <div class="zone-strip-head">
                  <strong>{item.label}</strong>
                  <span class="status-chip">{item.state}</span>
                </div>
                <div class="zone-strip-bar">
                  <span style={`width: ${item.load}%`} />
                </div>
                <div class="zone-strip-meta">
                  <span>{item.load}% load</span>
                  <span class={`signal-dot ${item.load > 85 ? 'warning' : item.load > 70 ? 'review' : 'live'}`} />
                </div>
              </div>
            ))}
          </div>
        </article>

        <article class="panel panel-span-two">
          <div class="panel-head">
            <div>
              <p class="eyebrow">Events</p>
              <h2>Recent activity</h2>
            </div>
          </div>
          <div class="table-wrap">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Event</th>
                  <th>Zone</th>
                  <th>Asset</th>
                  <th>Severity</th>
                  <th>Time</th>
                </tr>
              </thead>
              <tbody>
                {alarms.map((alarm) => (
                  <tr key={alarm.id}>
                    <td>
                      <strong>{alarm.id}</strong>
                      <div class="table-subtext">{alarm.summary}</div>
                    </td>
                    <td>{alarm.zone}</td>
                    <td>{alarm.asset}</td>
                    <td>
                      <span class="status-chip">{alarm.severity}</span>
                    </td>
                    <td>{alarm.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </article>
      </section>
    </AdminShell>
  </>
);

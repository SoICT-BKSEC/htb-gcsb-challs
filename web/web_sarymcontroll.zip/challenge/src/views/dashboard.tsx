import type { SessionUser } from '../types.js';

const supportRequests = [
  {
    reference: 'SAT-214',
    asset: 'Sarym-3 optical payload window',
    zone: 'Polar pass corridor',
    lane: 'Review',
    owner: 'Imaging desk'
  },
  {
    reference: 'SAT-221',
    asset: 'Antenna handoff sequence',
    zone: 'Balkhash ground node',
    lane: 'Scheduled',
    owner: 'Ground station'
  },
  {
    reference: 'SAT-228',
    asset: 'Synthetic aperture replay package',
    zone: 'Southern archive node',
    lane: 'Issued',
    owner: 'Archive desk'
  }
];

const zoneState = [
  { name: 'Northern imaging belt', state: 'Nominal', load: 82, signal: 'live' },
  { name: 'Eastern revisit track', state: 'Review', load: 67, signal: 'review' },
  { name: 'Southern downlink queue', state: 'Nominal', load: 74, signal: 'live' }
];

export const DashboardPage = ({ user: _user }: { user: SessionUser }) => (
  <>
    <title>Dashboard</title>
    <section>
      <div class="console-mast-copy">
        <p class="eyebrow">Dashboard</p>
        <h1>Control board</h1>
        <p class="lead">Active items, current status, and scheduled windows.</p>
      </div>
    </section>

    <section class="console-grid">
      <article class="panel panel-span-two">
        <div class="panel-head">
          <div>
            <p class="eyebrow">Map</p>
            <h2>Coverage map</h2>
          </div>
        </div>
        <div class="media-well orbit">
          <img class="media-image" src="/static/image4.png" alt="Coverage map" />
        </div>
      </article>

      <article class="panel panel-span-two">
        <div class="panel-head">
          <div>
            <p class="eyebrow">Queue</p>
            <h2>Current items</h2>
          </div>
        </div>
        <div class="queue-board">
          {['Review', 'Scheduled', 'Issued'].map((lane) => (
            <div class="queue-lane" key={lane}>
              <div class="queue-lane-head">
                <strong>{lane}</strong>
                <span class="status-chip">{supportRequests.filter((request) => request.lane === lane).length}</span>
              </div>
              <div class="queue-stack">
                {supportRequests
                  .filter((request) => request.lane === lane)
                  .map((request) => (
                    <div class="queue-ticket" key={request.reference}>
                      <strong>{request.reference}</strong>
                      <span>{request.asset}</span>
                      <div class="queue-ticket-meta">
                        <span>{request.zone}</span>
                        <span>{request.owner}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </article>

      <article class="panel panel-span-two">
        <div class="panel-head">
          <div>
            <p class="eyebrow">Status</p>
            <h2>Sector status</h2>
          </div>
        </div>
        <div class="zone-strip">
          {zoneState.map((zone) => (
            <div class="zone-strip-row" key={zone.name}>
              <div class="zone-strip-head">
                <strong>{zone.name}</strong>
                <span class="status-chip">{zone.state}</span>
              </div>
              <div class="zone-strip-bar">
                <span style={`width: ${zone.load}%`} />
              </div>
              <div class="zone-strip-meta">
                <span>{zone.load}% load</span>
                <span class={`signal-dot ${zone.signal}`} />
              </div>
            </div>
          ))}
        </div>
      </article>

      <article class="panel panel-span-two">
        <div class="panel-head">
          <div>
            <p class="eyebrow">Media</p>
            <h2>Primary display</h2>
          </div>
        </div>
        <div class="media-grid">
          <div class="media-well wide cinematic">
            <img class="media-image media-image-auto" src="/static/image1.png" alt="Primary display reference" />
          </div>
          <div class="media-well tall">
            <div class="media-stack">
              <img class="media-image" src="/static/imagae2.png" alt="Single pass frame reference" />
              <img class="media-image" src="/static/image3.png" alt="Secondary frame reference" />
            </div>
          </div>
        </div>
      </article>
    </section>
  </>
);

import type { PropsWithChildren } from 'hono/jsx';
import { useRequestContext } from 'hono/jsx-renderer';
import type { AppBindings } from '../app-types.js';

export const Layout = ({ children }: PropsWithChildren) => {
  const c = useRequestContext<AppBindings>();
  const user = c.get('currentUser');

  return (
    <html lang="en">
      <head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&display=swap"
          rel="stylesheet"
        />
        <link rel="stylesheet" href="/static/style.css?v=23" />
      </head>
      <body>
        <div class="site-frame">
          <header class="topbar">
            <div>
              <a class="brand" href="/">
                Sarym Orbital Control
              </a>
            </div>
            <nav>
              {user ? <a href="/dashboard">Dashboard</a> : <a href="/login">Sign in</a>}
              {user?.role === 'admin' ? <a href="/admin/overview">Admin</a> : null}
              {user ? (
                <form
                  action="/api/auth/logout"
                  data-json-form="true"
                  data-success-path="/"
                  data-error-path="/"
                  onsubmit="return false;"
                >
                  <button class="link-button" type="submit">
                    Sign out
                  </button>
                </form>
              ) : null}
            </nav>
          </header>
          <div class="topbar-rule" />
          <main class="shell">{children}</main>
          <div class="footer-spacer" aria-hidden="true" />
        </div>
        <script src="/static/app.js?v=5" defer></script>
      </body>
    </html>
  );
};

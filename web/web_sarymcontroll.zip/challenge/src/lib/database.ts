import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';

const initializeDatabase = () => {
  const databasePath = '/app/data/app.db';
  const schemaPath = '/app/src/db/schema.sql';

  fs.mkdirSync(path.dirname(databasePath), { recursive: true });

  const schema = fs.readFileSync(schemaPath, 'utf8');
  const database = new Database(databasePath);

  database.pragma('journal_mode = WAL');
  database.exec(schema);
  database
    .prepare(
      `INSERT OR IGNORE INTO app_settings (id, registration_enabled, default_role, updated_at)
       VALUES (1, 0, 'user', CURRENT_TIMESTAMP)`
    )
    .run();

  return database;
};

export const db = initializeDatabase();

const BASE_URL = "http://127.0.0.1:8484";
const AUTH_HEADER = process.env.GRIST_FORWARD_AUTH_HEADER || "X-Forwarded-User";
const ADMIN_EMAIL = process.env.GRIST_DEFAULT_EMAIL || "alex.caldwell@grist.htb";

const PUBLIC_WORKSPACE_NAME = "Announcements";
const PUBLIC_DOC = {
  name: "SSO-Rollout",
  urlId: "sso-rollout",
};
const PRIVATE_WORKSPACE_NAME = "Operations";
const PRIVATE_DOC = {
  name: "Automation-Lab",
  urlId: "automation-lab",
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function request(path, { method = "GET", json, asAdmin = true } = {}) {
  const headers = {};
  let body;

  if (asAdmin) {
    headers[AUTH_HEADER] = ADMIN_EMAIL;
  }
  if (json !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(json);
  }

  const response = await fetch(`${BASE_URL}${path}`, { method, headers, body });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`${method} ${path} failed with status ${response.status}: ${text}`);
  }

  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }
  return response.text();
}

async function waitForServer() {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    try {
      const session = await request("/api/session/access/active");
      if (session?.user?.email === ADMIN_EMAIL && session?.user?.isInstallAdmin) {
        return;
      }
    } catch (error) {
      if (attempt === 59) {
        throw error;
      }
    }
    await sleep(1000);
  }

  throw new Error("grist never became ready for seeding");
}

async function listWorkspaces() {
  return request("/api/orgs/current/workspaces");
}

async function ensureWorkspace(name) {
  const workspaces = await listWorkspaces();
  const existing = workspaces.find((workspace) => workspace.name === name);
  if (existing) {
    return existing.id;
  }

  return request("/api/orgs/current/workspaces", {
    method: "POST",
    json: { name },
  });
}

async function ensureDoc(workspaceId, { name, urlId }) {
  const workspaces = await listWorkspaces();
  for (const workspace of workspaces) {
    for (const doc of workspace.docs || []) {
      if (doc.urlId === urlId || doc.name === name) {
        return doc.id;
      }
    }
  }

  return request(`/api/workspaces/${workspaceId}/docs`, {
    method: "POST",
    json: { name, urlId },
  });
}

async function ensureTable(docId, tableId, columns, records) {
  const tableList = await request(`/api/docs/${docId}/tables`);
  const existingTables = new Set((tableList.tables || []).map((table) => table.id));
  if (existingTables.has(tableId)) {
    return;
  }

  const rows = Array.isArray(records) ? records : [records];
  const actions = [
    ["AddTable", tableId, columns],
    ...rows.map((record) => ["AddRecord", tableId, null, record]),
  ];

  await request(`/api/docs/${docId}/apply`, {
    method: "POST",
    json: actions,
  });
}

async function sharePublicDoc(docId) {
  await request(`/api/docs/${docId}/access`, {
    method: "PATCH",
    json: {
      delta: {
        users: {
          "everyone@getgrist.com": "viewers",
        },
      },
    },
  });

  for (let attempt = 0; attempt < 30; attempt += 1) {
    try {
      const records = await request(`/api/docs/${PUBLIC_DOC.urlId}/tables/Contacts/records`, {
        asAdmin: false,
      });
      const email = records?.records?.[0]?.fields?.Email;
      if (email === ADMIN_EMAIL) {
        return;
      }
    } catch (error) {
      if (attempt === 29) {
        throw error;
      }
    }
    await sleep(500);
  }

  throw new Error("public document never became anonymously readable");
}

async function seed() {
  await waitForServer();

  const publicWorkspaceId = await ensureWorkspace(PUBLIC_WORKSPACE_NAME);
  const privateWorkspaceId = await ensureWorkspace(PRIVATE_WORKSPACE_NAME);

  const publicDocId = await ensureDoc(publicWorkspaceId, PUBLIC_DOC);
  const privateDocId = await ensureDoc(privateWorkspaceId, PRIVATE_DOC);

  // --- Public: SSO-Rollout ---

  await ensureTable(
    publicDocId,
    "Contacts",
    [
      { id: "Team", type: "Text" },
      { id: "Email", type: "Text" },
      { id: "Notes", type: "Text" },
    ],
    [
      { Team: "Platform Admin",                   Email: ADMIN_EMAIL,                                    Notes: "Primary contact for platform access requests." },
      { Team: "National Election Commission",      Email: "sso-nec@election.gov.kv",                     Notes: "Awaiting onboarding — pending maintenance window." },
      { Team: "Ministry of Transport",             Email: "it-security@transport.gov.kv",                Notes: "Migration complete. MFA enrollment in progress." },
      { Team: "Korvia Banking Authority",          Email: "identity-ops@kba.fin.kv",                     Notes: "Active. Forward-auth verified against KBA IdP." },
      { Team: "Ministry of Interior",              Email: "sso-admin@interior.gov.kv",                   Notes: "Active. Credentials provisioned for all staff." },
    ],
  );

  await ensureTable(
    publicDocId,
    "Agencies",
    [
      { id: "Agency", type: "Text" },
      { id: "Sector", type: "Text" },
      { id: "Status", type: "Text" },
    ],
    [
      { Agency: "National Election Commission",  Sector: "Government", Status: "Pending — scheduled for next maintenance window" },
      { Agency: "Ministry of Transport",         Sector: "Mobility",   Status: "Active" },
      { Agency: "Korvia Banking Authority",       Sector: "Finance",    Status: "Active" },
      { Agency: "Ministry of Interior",           Sector: "Government", Status: "Active" },
    ],
  );

  // --- Private: Automation-Lab ---

  await ensureTable(
    privateDocId,
    "Runbook",
    [
      { id: "Topic", type: "Text" },
      { id: "Status", type: "Text" },
      { id: "Notes", type: "Text" },
    ],
    {
      Topic: "Formula runtime compatibility",
      Status: "Temporary exception",
      Notes:
        "Legacy workbooks still rely on Python formulas. Keep the current compatibility runtime in place until the sandbox migration is completed.",
    },
  );

  await ensureTable(
    privateDocId,
    "Operations",
    [
      { id: "Target", type: "Text" },
      { id: "Sector", type: "Text" },
      { id: "Method", type: "Text" },
      { id: "Status", type: "Text" },
    ],
    [
      { Target: "NEC-Auth-01",        Sector: "Election", Method: "Credential harvest via watering hole", Status: "Staged" },
      { Target: "Transit-SSO-Node",   Sector: "Mobility", Method: "Lateral movement via LOLBin",          Status: "Access established" },
      { Target: "KBA-IdP-Cluster",    Sector: "Finance",  Method: "Supply chain implant",                 Status: "Dormant" },
    ],
  );

  await ensureTable(
    privateDocId,
    "Intel",
    [
      { id: "Date", type: "Text" },
      { id: "Classification", type: "Text" },
      { id: "Summary", type: "Text" },
    ],
    [
      { Date: "2026-04-20", Classification: "TECHINT", Summary: "SSO gateway deployed without header sanitization audit — access vector confirmed." },
      { Date: "2026-04-23", Classification: "SIGINT",  Summary: "Election Commission IdP migration confirmed — window opens 48 hours before polls." },
      { Date: "2026-04-26", Classification: "HUMINT",  Summary: "Insider confirms sandbox migration deferred — Python runtime remains active." },
    ],
  );

  await sharePublicDoc(publicDocId);
  console.log("[*] Challenge data seeded");
}

seed().catch((error) => {
  console.error(`[-] Seeding failed: ${error.message}`);
  process.exit(1);
});

#!/bin/bash
set -euo pipefail

ORIGINAL_ENTRYPOINT="/grist/sandbox/docker_entrypoint.sh"
GRIST_PID=""

cleanup() {
  [[ -n "$GRIST_PID" ]] && kill "$GRIST_PID" 2>/dev/null || true
  nginx -s stop 2>/dev/null || true
}

trap cleanup EXIT INT TERM

nginx

cd /grist
if [[ "$#" -eq 0 ]]; then
  set -- node ./sandbox/supervisor.mjs
fi
"$ORIGINAL_ENTRYPOINT" "$@" &
GRIST_PID=$!

node /seed-challenge.mjs

wait "$GRIST_PID"

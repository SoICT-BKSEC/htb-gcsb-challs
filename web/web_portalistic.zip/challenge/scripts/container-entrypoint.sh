#!/bin/bash
set -euo pipefail

MYSQL_DATA_DIR="/var/lib/mysql"
MYSQL_SOCKET="/var/run/mysqld/mysqld.sock"
BOOTSTRAP_PID=""
MYSQL_ROOT_PASSWORD="korvia_root_password"
DB_NAME="korvia_exchange"
DB_USER="korvia_app"
DB_PASSWORD="korvia_app_password"

mkdir -p /logs /app/runtime /app/storage/uploads /var/run/mysqld /var/lib/nginx/body /tmp/nginx
chown -R mysql:mysql /var/run/mysqld "${MYSQL_DATA_DIR}"
chown -R portal:portal /logs /app/runtime /app/storage/uploads /var/lib/nginx /tmp/nginx

stop_bootstrap_db() {
  if [ -n "${BOOTSTRAP_PID}" ] && kill -0 "${BOOTSTRAP_PID}" 2>/dev/null; then
    if mysql_ready_without_password; then
      mysqladmin -uroot --socket="${MYSQL_SOCKET}" shutdown >/dev/null 2>&1 || true
    elif mysql_ready_with_password; then
      mysqladmin -uroot -p"${MYSQL_ROOT_PASSWORD}" --socket="${MYSQL_SOCKET}" shutdown >/dev/null 2>&1 || true
    else
      kill "${BOOTSTRAP_PID}" 2>/dev/null || true
    fi

    wait "${BOOTSTRAP_PID}" || true
    BOOTSTRAP_PID=""
  fi
}

trap stop_bootstrap_db EXIT INT TERM

mysql_ready_without_password() {
  mysql -uroot --socket="${MYSQL_SOCKET}" -e "SELECT 1;" >/dev/null 2>&1
}

mysql_ready_with_password() {
  mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" --socket="${MYSQL_SOCKET}" -e "SELECT 1;" >/dev/null 2>&1
}

if [ ! -d "${MYSQL_DATA_DIR}/mysql" ]; then
  mariadb-install-db --user=mysql --datadir="${MYSQL_DATA_DIR}" >/tmp/ktx-mariadb-init.log
fi

/usr/bin/mysqld_safe --datadir="${MYSQL_DATA_DIR}" --bind-address=127.0.0.1 --socket="${MYSQL_SOCKET}" --pid-file=/var/run/mysqld/bootstrap.pid >/dev/stdout 2>/dev/stderr &
BOOTSTRAP_PID=$!

for _ in $(seq 1 60); do
  if mysql_ready_without_password; then
    break
  fi

  if mysql_ready_with_password; then
    break
  fi

  sleep 1
done

if mysql_ready_without_password; then
 mysql -uroot --socket="${MYSQL_SOCKET}" <<SQL
ALTER USER 'root'@'localhost' IDENTIFIED BY '${MYSQL_ROOT_PASSWORD}';
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`;
CREATE USER IF NOT EXISTS '${DB_USER}'@'%' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'%';
FLUSH PRIVILEGES;
SQL
else
  mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" --socket="${MYSQL_SOCKET}" <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`;
CREATE USER IF NOT EXISTS '${DB_USER}'@'%' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'%';
FLUSH PRIVILEGES;
SQL
fi

node /app/lib/bootstrap.js

stop_bootstrap_db
trap - EXIT INT TERM

exec /usr/bin/supervisord -n -c /etc/supervisor/conf.d/korvia.conf

import AppShell from '../components/AppShell';
import TableCard from '../components/TableCard';
import { requireUser } from '../lib/pageProps';
import { listPaymentRequestsForUser } from '../lib/services/payments';
import { useTranslation } from 'next-i18next/pages';

export default function PaymentsPage({ currentUser, payments }) {
  const { t } = useTranslation('common');

  return (
    <AppShell currentUser={currentUser} title={t('payments.title')} intro={t('payments.intro')}>
      <TableCard
        title={t('payments.tableTitle')}
        description={t('payments.tableIntro')}
        columns={[t('tables.reference'), t('tables.summary'), t('tables.status'), t('tables.dueDate'), t('tables.amount')]}
        rows={payments}
        renderRow={(row) => (
          <tr key={row.id}>
            <td>{row.reference_code}</td>
            <td>{row.summary}</td>
            <td><span className={`status-pill status-${row.status}`}>{t(`statuses.${row.status}`)}</span></td>
            <td>{new Date(row.due_date).toISOString().slice(0, 10)}</td>
            <td>{row.currency} {(row.amount_cents / 100).toLocaleString()}</td>
          </tr>
        )}
      />
    </AppShell>
  );
}

export async function getServerSideProps(context) {
  const gate = await requireUser(context, {}, ['supplier']);
  if ('redirect' in gate) return gate;

  return { props: { ...gate.props, payments: await listPaymentRequestsForUser(gate.props.currentUser.id) } };
}

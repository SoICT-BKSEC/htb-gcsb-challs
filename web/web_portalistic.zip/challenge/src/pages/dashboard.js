import AppShell from '../components/AppShell';
import TableCard from '../components/TableCard';
import { requireUser } from '../lib/pageProps';
import { listDocumentsForUser } from '../lib/services/documents';
import { listPaymentRequestsForUser } from '../lib/services/payments';
import { useTranslation } from 'next-i18next/pages';

export default function DashboardPage({ currentUser, documents, payments }) {
  const { t } = useTranslation('common');

  return (
    <AppShell currentUser={currentUser} title={t('dashboard.title')} intro={t('dashboard.intro')}>
      <section className="page-stack">
        <TableCard
          title={t('dashboard.tables.paymentsTitle')}
          description={t('dashboard.tables.paymentsIntro')}
          columns={[t('tables.reference'), t('tables.status'), t('tables.dueDate'), t('tables.amount')]}
          rows={payments.slice(0, 4)}
          renderRow={(row) => (
            <tr key={row.id}>
              <td>{row.reference_code}</td>
              <td><span className={`status-pill status-${row.status}`}>{t(`statuses.${row.status}`)}</span></td>
              <td>{new Date(row.due_date).toISOString().slice(0, 10)}</td>
              <td>{row.currency} {(row.amount_cents / 100).toLocaleString()}</td>
            </tr>
          )}
        />
      </section>
      <section className="page-stack">
        <TableCard
          title={t('dashboard.tables.documentsTitle')}
          description={t('dashboard.tables.documentsIntro')}
          columns={[t('tables.title'), t('tables.type'), t('tables.status')]}
          rows={documents.slice(0, 4)}
          renderRow={(row) => (
            <tr key={row.id}>
              <td>{row.title}</td>
              <td>{row.document_type}</td>
              <td><span className={`status-pill status-${row.status}`}>{t(`statuses.${row.status}`)}</span></td>
            </tr>
          )}
        />
      </section>
    </AppShell>
  );
}

export async function getServerSideProps(context) {
  const gate = await requireUser(context, {}, ['supplier']);
  if ('redirect' in gate) return gate;

  const userId = gate.props.currentUser.id;
  const [documents, payments] = await Promise.all([
    listDocumentsForUser(userId),
    listPaymentRequestsForUser(userId)
  ]);

  return { props: { ...gate.props, documents, payments } };
}


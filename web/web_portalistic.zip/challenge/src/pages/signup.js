import { useState } from 'react';
import { useRouter } from 'next/router';
import { useTranslation } from 'next-i18next/pages';
import PublicShell from '../components/PublicShell';
import { requireGuest } from '../lib/pageProps';

function slugify(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '.')
    .replace(/^\.+|\.+$/g, '')
    .slice(0, 8);
}

export default function SignupPage() {
  const { t } = useTranslation('common');
  const router = useRouter();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setLoading(true);
    setError('');

    const formData = new FormData(event.currentTarget);
    const organizationName = String(formData.get('organizationName') || '');
    const payload = {
      displayName: organizationName,
      organizationName,
      contactName: String(formData.get('contactName') || ''),
      contactEmail: String(formData.get('email') || ''),
      email: String(formData.get('email') || ''),
      phone: String(formData.get('phone') || ''),
      password: String(formData.get('password') || ''),
      username: slugify(organizationName)
    };

    const response = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (!response.ok) {
      setError(result.message || t('auth.errors.signup'));
      setLoading(false);
      return;
    }

    router.push(result.redirectTo || '/verify-account');
  }

  return (
    <PublicShell title={t('auth.signupTitle')} intro={t('auth.signupIntro')}>
      <section className="public-section narrow-section">
        <form className="stacked-form form-shell" onSubmit={handleSubmit}>
          <label>
            <span>{t('auth.organization')}</span>
            <input name="organizationName" required />
          </label>
          <label>
            <span>{t('auth.contactName')}</span>
            <input name="contactName" required />
          </label>
          <label>
            <span>{t('auth.email')}</span>
            <input name="email" type="email" required />
          </label>
          <label>
            <span>{t('auth.phone')}</span>
            <input name="phone" />
          </label>
          <label>
            <span>{t('auth.password')}</span>
            <input name="password" type="password" required />
          </label>
          <div className="actions">
            <button className="primary-button" type="submit" disabled={loading}>
              {loading ? t('shared.loading') : t('auth.signup')}
            </button>
          </div>
          {error ? <p className="form-error">{error}</p> : null}
        </form>
      </section>
    </PublicShell>
  );
}

export const getServerSideProps = requireGuest;

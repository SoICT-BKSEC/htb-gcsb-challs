import AppShell from '../components/AppShell';
import TableCard from '../components/TableCard';
import { baseProps, requireUser } from '../lib/pageProps';
import { getDefaultRouteForRole, getSessionUser } from '../lib/auth/session';
import { isForbiddenFormSubmission } from '../lib/csrf';
import { listDocumentsForUser, parseDocumentUpload, saveDocumentUpload } from '../lib/services/documents';
import { useTranslation } from 'next-i18next/pages';

function redirect(destination) {
  return {
    redirect: {
      destination,
      permanent: false
    }
  };
}

async function requireSupplierPageUser(context) {
  const user = await getSessionUser(context.req);

  if (!user) return redirect('/login');
  if (user.role !== 'supplier') return redirect(getDefaultRouteForRole(user.role));
  if (!user.verified) return redirect(`/verify-account?email=${encodeURIComponent(user.email)}`);
  if (!user.approved) return redirect('/login');

  return user;
}

async function documentsProps(locale, user) {
  return {
    props: await baseProps(locale, {
      currentUser: user,
      documents: await listDocumentsForUser(user.id)
    })
  };
}

export default function DocumentsPage({ currentUser, documents }) {
  const { t } = useTranslation('common');

  return (
    <AppShell currentUser={currentUser} title={t('documents.title')} intro={t('documents.intro')}>
      <section className="page-stack">
        <article className="card">
          <h2>{t('documents.formTitle')}</h2>
          <form className="stacked-form" method="POST" encType="multipart/form-data">
            <label><span>{t('documents.fields.title')}</span><input name="title" required /></label>
            <label>
              <span>{t('documents.fields.type')}</span>
              <select name="documentType" defaultValue="invoice">
                <option value="invoice">{t('documentTypes.invoice')}</option>
                <option value="compliance">{t('documentTypes.compliance')}</option>
                <option value="delivery">{t('documentTypes.delivery')}</option>
                <option value="supporting-record">{t('documentTypes.supporting')}</option>
              </select>
            </label>
            <label><span>{t('documents.fields.notes')}</span><textarea name="notes" rows="6" /></label>
            <label><span>{t('documents.fields.file')}</span><input name="file" type="file" required /></label>
            <button className="primary-button" type="submit">{t('documents.submit')}</button>
          </form>
        </article>
      </section>

      <section className="page-stack">
        <TableCard
          title={t('documents.tableTitle')}
          description={t('documents.tableIntro')}
          columns={[t('tables.title'), t('tables.type'), t('tables.status'), t('tables.size')]}
          rows={documents}
          renderRow={(row) => (
            <tr key={row.id}>
              <td>{row.title}</td>
              <td>{row.document_type}</td>
              <td><span className={`status-pill status-${row.status}`}>{t(`statuses.${row.status}`)}</span></td>
              <td>{Math.round(row.size_bytes / 1024)} KB</td>
            </tr>
          )}
        />
      </section>
    </AppShell>
  );
}

export async function getServerSideProps(context) {
  if (context.req.method === 'POST') {
    const user = await requireSupplierPageUser(context);
    if ('redirect' in user) return user;

    if (isForbiddenFormSubmission(context.req)) {
      context.res.statusCode = 403;
      return documentsProps(context.locale, user);
    }

    try {
      const parsed = await parseDocumentUpload(context.req, context.res);
      await saveDocumentUpload(user, parsed, { status: 'submitted' });
    } catch {
      return redirect('/documents');
    }

    return redirect('/documents');
  }

  const gate = await requireUser(context, {}, ['supplier']);
  if ('redirect' in gate) return gate;

  return { props: { ...gate.props, documents: await listDocumentsForUser(gate.props.currentUser.id) } };
}

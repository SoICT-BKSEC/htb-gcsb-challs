import PublicShell from '../components/PublicShell';
import { baseProps } from '../lib/pageProps';
import { useTranslation } from 'next-i18next/pages';

export default function Home() {
  const { t } = useTranslation('common');

  const pills = [
    t('home.pillOne'),
    t('home.pillTwo'),
    t('home.pillThree'),
  ];

  return (
    <PublicShell
      title={t('home.title')}
      intro={t('home.intro')}
      pills={pills}
    />
  );
}

export async function getServerSideProps({ locale }) {
  return {
    props: await baseProps(locale)
  };
}

import AppShell from '../../components/AppShell';
import TableCard from '../../components/TableCard';
import { requireUser } from '../../lib/pageProps';
import { listSupplierUsers } from '../../lib/services/users';
import { useTranslation } from 'next-i18next/pages';
import { useState } from 'react';

export default function AdminSuppliersPage({ currentUser, suppliers }) {
  const { t } = useTranslation('common');
  const [message, setMessage] = useState('');

  async function handleApprove(userId) {
    setMessage('');
    const response = await fetch('/api/admin/suppliers/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: userId })
    });
    const result = await response.json();
    setMessage(response.ok ? t('admin.suppliers.approved') : (result.message || t('admin.suppliers.error')));
    if (response.ok) {
      window.location.reload();
    }
  }

  function renderState(row) {
    if (row.approved) {
      return { className: 'approved', label: t('admin.suppliers.states.approved') };
    }
    if (row.verified) {
      return { className: 'under_review', label: t('admin.suppliers.states.awaitingApproval') };
    }
    return { className: 'pending', label: t('admin.suppliers.states.awaitingVerification') };
  }

  return (
    <AppShell currentUser={currentUser} title={t('admin.supplierPageTitle')} intro={t('admin.supplierPageIntro')}>
      <TableCard
        title={t('admin.supplierPageTableTitle')}
        description={t('admin.supplierPageTableIntro')}
        columns={[t('tables.organization'), t('tables.contact'), t('tables.email'), t('tables.phone'), t('tables.status'), t('tables.actions')]}
        rows={suppliers}
        renderRow={(row) => {
          const state = renderState(row);
          return (
          <tr key={row.id}>
            <td>{row.organization_name}</td>
            <td>{row.contact_name}</td>
            <td>{row.contact_email || row.email}</td>
            <td>{row.phone || '-'}</td>
            <td><span className={`status-pill status-${state.className}`}>{state.label}</span></td>
            <td>
              {row.verified && !row.approved ? (
                <button className="secondary-button" type="button" onClick={() => handleApprove(row.id)}>
                  {t('admin.suppliers.approve')}
                </button>
              ) : '—'}
            </td>
          </tr>
        )}}
      />
      {message ? <p className="form-status top-gap">{message}</p> : null}
    </AppShell>
  );
}

export async function getServerSideProps(context) {
  const gate = await requireUser(context, {}, ['admin']);
  if ('redirect' in gate) return gate;

  return { props: { ...gate.props, suppliers: await listSupplierUsers() } };
}

import AppShell from '../../components/AppShell';
import TableCard from '../../components/TableCard';
import { requireUser } from '../../lib/pageProps';
import { listSupplierUsers } from '../../lib/services/users';
import { listPaymentRequests } from '../../lib/services/payments';
import { useTranslation } from 'next-i18next/pages';

export default function AdminDashboardPage({ currentUser, suppliers, payments }) {
  const { t } = useTranslation('common');

  return (
    <AppShell currentUser={currentUser} title={t('admin.dashboardTitle')} intro={t('admin.dashboardIntro')}>
      <section className="page-stack">
        <TableCard
          title={t('admin.suppliersTitle')}
          description={t('admin.suppliersIntro')}
          columns={[t('tables.organization'), t('tables.contact'), t('tables.email')]}
          rows={suppliers.slice(0, 6)}
          renderRow={(row) => (
            <tr key={row.id}><td>{row.organization_name}</td><td>{row.contact_name}</td><td>{row.email}</td></tr>
          )}
        />
      </section>
      <section className="page-stack">
        <TableCard
          title={t('admin.paymentsTitle')}
          description={t('admin.paymentsIntro')}
          columns={[t('tables.reference'), t('tables.organization'), t('tables.status')]}
          rows={payments.slice(0, 6)}
          renderRow={(row) => (
            <tr key={row.id}><td>{row.reference_code}</td><td>{row.organization_name}</td><td><span className={`status-pill status-${row.status}`}>{t(`statuses.${row.status}`)}</span></td></tr>
          )}
        />
      </section>
    </AppShell>
  );
}

export async function getServerSideProps(context) {
  const gate = await requireUser(context, {}, ['admin']);
  if ('redirect' in gate) return gate;

  const [suppliers, payments] = await Promise.all([listSupplierUsers(), listPaymentRequests(12)]);
  return { props: { ...gate.props, suppliers, payments } };
}

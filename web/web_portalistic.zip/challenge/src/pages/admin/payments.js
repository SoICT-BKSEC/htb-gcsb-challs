import { useState } from 'react';
import AppShell from '../../components/AppShell';
import { requireUser } from '../../lib/pageProps';
import { listPaymentRequests } from '../../lib/services/payments';
import { useTranslation } from 'next-i18next/pages';

export default function AdminPaymentsPage({ currentUser, payments }) {
  const { t } = useTranslation('common');
  const [message, setMessage] = useState('');

  async function handleUpdate(event, paymentId) {
    event.preventDefault();
    setMessage('');
    const formData = new FormData(event.currentTarget);
    const response = await fetch('/api/admin/payments/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: paymentId, status: formData.get('status') })
    });
    const result = await response.json();
    setMessage(response.ok ? t('admin.paymentSaved') : (result.message || t('admin.paymentError')));
    if (response.ok) window.location.reload();
  }

  return (
    <AppShell currentUser={currentUser} title={t('admin.paymentPageTitle')} intro={t('admin.paymentPageIntro')}>
      <section className="card">
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{t('tables.reference')}</th>
                <th>{t('tables.organization')}</th>
                <th>{t('tables.summary')}</th>
                <th>{t('tables.status')}</th>
                <th>{t('tables.amount')}</th>
                <th>{t('tables.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((row) => (
                <tr key={row.id}>
                  <td>{row.reference_code}</td>
                  <td>{row.organization_name}</td>
                  <td>{row.summary}</td>
                  <td><span className={`status-pill status-${row.status}`}>{t(`statuses.${row.status}`)}</span></td>
                  <td>{row.currency} {(row.amount_cents / 100).toLocaleString()}</td>
                  <td>
                    <form className="inline-form" onSubmit={(event) => handleUpdate(event, row.id)}>
                      <select name="status" defaultValue={row.status}>
                        <option value="pending">{t('statuses.pending')}</option>
                        <option value="under_review">{t('statuses.under_review')}</option>
                        <option value="approved">{t('statuses.approved')}</option>
                        <option value="on_hold">{t('statuses.on_hold')}</option>
                      </select>
                      <button className="secondary-button" type="submit">{t('shared.save')}</button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {message ? <p className="form-status top-gap">{message}</p> : null}
      </section>
    </AppShell>
  );
}

export async function getServerSideProps(context) {
  const gate = await requireUser(context, {}, ['admin']);
  if ('redirect' in gate) return gate;

  return { props: { ...gate.props, payments: await listPaymentRequests(30) } };
}

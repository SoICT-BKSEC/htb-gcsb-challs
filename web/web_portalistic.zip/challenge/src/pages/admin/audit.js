import { useState } from 'react';
import AppShell from '../../components/AppShell';
import TableCard from '../../components/TableCard';
import { requireUser } from '../../lib/pageProps';
import { listAuditReports, userAuditFields } from '../../lib/services/auditReports';
import { useTranslation } from 'next-i18next/pages';

const DEFAULT_FILTERS = [{ userField: 'email', userValue: '' }];

export default function AdminAuditPage({ currentUser, availableUserFields, reports }) {
  const { t } = useTranslation('common');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);

  function updateFilter(index, key, value) {
    setFilters((current) =>
      current.map((entry, entryIndex) => (entryIndex === index ? { ...entry, [key]: value } : entry))
    );
  }

  function addFilter() {
    setFilters((current) => [...current, { userField: availableUserFields[0] || 'email', userValue: '' }]);
  }

  function removeFilter(index) {
    setFilters((current) => {
      if (current.length === 1) {
        return current;
      }

      return current.filter((_, entryIndex) => entryIndex !== index);
    });
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setLoading(true);
    setMessage('');
    setError('');

    const payload = {
      userField: filters.map((entry) => entry.userField),
      userValue: filters.map((entry) => entry.userValue)
    };

    const response = await fetch('/api/admin/audit/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const result = await response.json();
    if (!result.ok) {
      setError(result.message || t('admin.auditError'));
      setLoading(false);
      return;
    }

    if (!result.report) {
      setMessage(t('admin.auditEmpty'));
      setLoading(false);
      return;
    }

    setMessage(t('admin.auditSaved'));
    setLoading(false);
    window.location.reload();
  }

  return (
    <AppShell currentUser={currentUser} title={t('admin.auditTitle')} intro={t('admin.auditIntro')}>
      <section className="card">
        <div className="section-heading compact-heading">
          <div>
            <h2>{t('admin.auditBuilderTitle')}</h2>
            <p>{t('admin.auditBuilderIntro')}</p>
          </div>
          <button className="secondary-button" type="button" onClick={addFilter}>
            {t('admin.auditAddFilter')}
          </button>
        </div>
        <form className="stacked-form gap-lg" onSubmit={handleSubmit}>
          {filters.map((filter, index) => (
            <div key={`filter-${index}`} className="audit-filter-card">
              <div className="audit-filter-card-head">
                <span className="role-chip role-supplier">{t('admin.auditFilterLabel', { index: index + 1 })}</span>
                <button
                  className="ghost-link"
                  type="button"
                  onClick={() => removeFilter(index)}
                  disabled={filters.length === 1}
                >
                  {t('admin.auditRemoveFilter')}
                </button>
              </div>
              <div className="audit-filter-row">
                <label>
                  <span>{t('admin.filters.userField')}</span>
                  <select
                    value={filter.userField}
                    onChange={(event) => updateFilter(index, 'userField', event.target.value)}
                  >
                    {availableUserFields.map((field) => (
                      <option key={field} value={field}>
                        {field}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  <span>{t('admin.filters.userValue')}</span>
                  <input value={filter.userValue} onChange={(event) => updateFilter(index, 'userValue', event.target.value)} />
                </label>
              </div>
            </div>
          ))}
          <div className="stacked-submit audit-submit-bar">
            <span>{t('admin.auditHint')}</span>
            <div className="topbar-actions">
              <button className="primary-button" type="submit" disabled={loading}>
                {loading ? t('shared.loading') : t('admin.auditSubmit')}
              </button>
            </div>
          </div>
        </form>
        {message ? <p className="form-status top-gap">{message}</p> : null}
        {error ? <p className="form-error top-gap">{error}</p> : null}
      </section>

      <TableCard
        title={t('admin.auditReportsTitle')}
        description={t('admin.auditReportsIntro')}
        columns={[t('tables.title'), t('tables.summary'), t('tables.requested'), t('tables.actions')]}
        rows={reports}
        renderRow={(row) => (
          <tr key={row.id}>
            <td>{row.file_name}</td>
            <td>{row.filters.map((entry) => `${entry.key}=${entry.value}`).join(', ')}</td>
            <td>{new Date(row.created_at).toISOString().slice(0, 16).replace('T', ' ')}</td>
            <td><a className="ghost-link" href={`/api/admin/audit/reports/${row.id}`} target="_blank" rel="noreferrer">{t('admin.auditOpen')}</a></td>
          </tr>
        )}
      />
    </AppShell>
  );
}

export async function getServerSideProps(context) {
  const gate = await requireUser(context, {}, ['admin']);
  if ('redirect' in gate) return gate;

  return { props: { ...gate.props, availableUserFields: userAuditFields, reports: await listAuditReports() } };
}

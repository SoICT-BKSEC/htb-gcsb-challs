import { useState } from 'react';
import { useTranslation } from 'next-i18next/pages';
import PublicShell from '../components/PublicShell';
import { requireGuest } from '../lib/pageProps';

export default function VerifyAccountPage({ defaultEmail }) {
  const { t } = useTranslation('common');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [verifiedEmail, setVerifiedEmail] = useState('');
  const [verifiedCode, setVerifiedCode] = useState('');
  const [approvalMessage, setApprovalMessage] = useState('');
  const [approvalError, setApprovalError] = useState('');
  const [approvalLoading, setApprovalLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setLoading(true);
    setMessage('');
    setError('');
    setApprovalMessage('');
    setApprovalError('');

    const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
    const response = await fetch('/api/auth/verify-account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await response.json();

    if (!response.ok) {
      setError(result.message || t('verification.error'));
      setLoading(false);
      return;
    }

    setMessage(t('verification.saved'));
    setVerifiedEmail(String(payload.email || ''));
    setVerifiedCode(String(payload.code || '').toUpperCase());
    setLoading(false);
  }

  async function handleApprovalRequest(event) {
    event.preventDefault();
    setApprovalLoading(true);
    setApprovalMessage('');
    setApprovalError('');

    const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
    const response = await fetch('/api/access-requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: verifiedEmail,
        code: verifiedCode,
        companyUrl: payload.companyUrl
      })
    });
    const result = await response.json();

    if (!response.ok) {
      setApprovalError(result.message || t('verification.approvalError'));
      setApprovalLoading(false);
      return;
    }

    setApprovalMessage(result.message || t('verification.approvalSaved'));
    setApprovalLoading(false);
  }

  return (
    <PublicShell title={t('verification.title')} intro={t('verification.intro')}>
      <section className="public-section narrow-section">
        <div className="form-shell stacked-form gap-lg">
          <p className="form-status">{t('verification.waitingNote')}</p>
          <form className="stacked-form" onSubmit={handleSubmit}>
            <label>
              <span>{t('auth.email')}</span>
              <input name="email" type="email" defaultValue={defaultEmail} required />
            </label>
            <label>
              <span>{t('verification.code')}</span>
              <input name="code" required />
            </label>
            <button className="primary-button" type="submit" disabled={loading}>
              {loading ? t('shared.loading') : t('verification.submit')}
            </button>
            {message ? <p className="form-status">{message}</p> : null}
            {error ? <p className="form-error">{error}</p> : null}
          </form>
          {verifiedEmail ? (
            <form className="stacked-form" onSubmit={handleApprovalRequest}>
              <label>
                <span>{t('verification.companyUrl')}</span>
                <input name="companyUrl" type="url" placeholder="https://example.com" required />
              </label>
              <button className="secondary-button" type="submit" disabled={approvalLoading}>
                {approvalLoading ? t('shared.loading') : t('verification.approvalSubmit')}
              </button>
              {approvalMessage ? <p className="form-status">{approvalMessage}</p> : null}
              {approvalError ? <p className="form-error">{approvalError}</p> : null}
            </form>
          ) : null}
          {verifiedEmail ? (
            <div className="status-card">
              <strong>{t('verification.code')}</strong>
              <p>{verifiedCode || defaultEmail || '—'}</p>
            </div>
          ) : null}
        </div>
      </section>
    </PublicShell>
  );
}

export async function getServerSideProps(context) {
  const gate = await requireGuest(context);
  if ('redirect' in gate) return gate;

  return {
    props: {
      ...gate.props,
      defaultEmail: String(context.query.email || '')
    }
  };
}

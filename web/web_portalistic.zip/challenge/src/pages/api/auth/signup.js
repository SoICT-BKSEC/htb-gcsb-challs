import { createSupplierUser } from '../../../lib/services/users';
import { ensureMethod, guardCsrf, parseJsonBody } from '../../../lib/request';
import { generateToken } from '../../../lib/auth/passwords';

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (!ensureMethod(req, res, ['POST'])) return;
  if (!guardCsrf(req, res)) return;
  if (!(await parseJsonBody(req, res))) return;

  const { displayName, organizationName, username, email, phone, password, contactName, contactEmail } = req.body || {};

  if (!displayName || !organizationName || !username || !email || !password || !contactName) {
    return res.status(400).json({ ok: false, message: 'Please complete all required fields.' });
  }

  try {
    const user = await createSupplierUser({
      displayName: String(displayName).trim(),
      organizationName: String(organizationName).trim(),
      username: String(username).trim().toLowerCase(),
      email: String(email).trim().toLowerCase(),
      phone: String(phone || '').trim(),
      password: String(password),
      contactName: String(contactName).trim(),
      contactEmail: String(contactEmail || email).trim().toLowerCase(),
      locale: 'en',
      verificationCode: generateToken(4).toUpperCase()
    });
    return res.status(201).json({
      ok: true,
      user,
      requiresVerification: true,
      redirectTo: `/verify-account?email=${encodeURIComponent(user.email)}`
    });
  } catch (error) {
    return res.status(error.statusCode || 500).json({ ok: false, message: error.message || 'Unable to create account.' });
  }
}

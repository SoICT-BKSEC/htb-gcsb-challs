import { destroySession } from '../../../lib/auth/session';
import { ensureMethod, guardCsrf } from '../../../lib/request';

export default async function handler(req, res) {
  if (!ensureMethod(req, res, ['POST'])) return;
  if (!guardCsrf(req, res)) return;

  await destroySession(req, res);
  return res.status(200).json({ ok: true });
}

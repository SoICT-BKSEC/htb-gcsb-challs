import { ensureMethod, guardCsrf, parseJsonBody } from '../../../lib/request';
import { verifySupplierCode } from '../../../lib/services/users';

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (!ensureMethod(req, res, ['POST'])) return;
  if (!guardCsrf(req, res)) return;
  if (!(await parseJsonBody(req, res))) return;

  const { email, code } = req.body || {};
  if (!email || !code) {
    return res.status(400).json({ ok: false, message: 'Email and code are required.' });
  }

  const user = await verifySupplierCode(email, code);
  if (!user) {
    return res.status(404).json({ ok: false, message: 'Verification code could not be used.' });
  }

  return res.status(200).json({ ok: true, user });
}

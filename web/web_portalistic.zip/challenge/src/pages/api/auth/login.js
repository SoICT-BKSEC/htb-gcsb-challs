import { attachSessionCookie, createSession } from '../../../lib/auth/session';
import { authenticateUser } from '../../../lib/services/users';
import { ensureMethod, guardCsrf, parseJsonBody } from '../../../lib/request';

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (!ensureMethod(req, res, ['POST'])) return;
  if (!guardCsrf(req, res)) return;
  if (!(await parseJsonBody(req, res))) return;

  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ ok: false, message: 'Email and password are required.' });
  }

  const user = await authenticateUser(String(email).trim().toLowerCase(), String(password));
  if (!user) {
    return res.status(401).json({ ok: false, message: 'Invalid credentials.' });
  }

  if (user.role !== 'admin' && !user.verified) {
    return res.status(403).json({
      ok: false,
      message: 'Account verification is still pending.',
      redirectTo: `/verify-account?email=${encodeURIComponent(user.email)}`
    });
  }

  if (user.role !== 'admin' && !user.approved) {
    return res.status(403).json({
      ok: false,
      message: 'Account approval is still pending.'
    });
  }

  const session = await createSession(user.id);
  attachSessionCookie(res, session.rawToken, session.expiresAt);
  return res.status(200).json({
    ok: true,
    redirectTo: user.role === 'admin' ? '/admin/dashboard' : '/dashboard'
  });
}

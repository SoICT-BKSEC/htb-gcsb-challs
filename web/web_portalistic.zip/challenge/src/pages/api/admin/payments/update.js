import { requireApiUser } from '../../../../lib/auth/session';
import { ensureMethod, guardCsrf, parseJsonBody } from '../../../../lib/request';
import { updatePaymentStatus } from '../../../../lib/services/payments';

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (!ensureMethod(req, res, ['POST'])) return;
  if (!guardCsrf(req, res)) return;
  if (!(await parseJsonBody(req, res))) return;

  const user = await requireApiUser(req, res, ['admin']);
  if (!user) return;

  const { id, status } = req.body || {};
  if (!id || !['pending', 'under_review', 'approved', 'on_hold'].includes(String(status))) {
    return res.status(400).json({ ok: false, message: 'Invalid payment update.' });
  }

  await updatePaymentStatus(Number(id), String(status));
  return res.status(200).json({ ok: true });
}

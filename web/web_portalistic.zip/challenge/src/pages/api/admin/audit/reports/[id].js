import { getSessionUser } from '../../../../../lib/auth/session';
import { readAuditReport } from '../../../../../lib/services/auditReports';
import { ensureMethod } from '../../../../../lib/request';

export default async function handler(req, res) {
  if (!ensureMethod(req, res, ['GET'])) return;

  const reportId = Number(req.query?.id);
  if (!Number.isFinite(reportId) || reportId <= 0) {
    return res.status(400).json({ ok: false, message: 'Invalid audit report.' });
  }

  const report = await readAuditReport(reportId);
  if (!report) {
    return res.status(404).json({ ok: false, message: 'Audit report not found.' });
  }

  const user = await getSessionUser(req);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ ok: false, message: 'Insufficient permissions.' });
  }

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="${report.file_name}"`);
  res.setHeader('Cache-Control', 'private, no-store');
  return res.status(200).send(report.buffer);
}

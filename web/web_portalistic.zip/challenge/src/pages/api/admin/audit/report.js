import { requireApiUser } from '../../../../lib/auth/session';
import { generateAuditReport } from '../../../../lib/services/auditReports';
import { ensureMethod, guardCsrf, parseJsonBody } from '../../../../lib/request';

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (!ensureMethod(req, res, ['POST'])) return;
  if (!guardCsrf(req, res)) return;
  if (!(await parseJsonBody(req, res))) return;

  const user = await requireApiUser(req, res, ['admin']);
  if (!user) return;

  const results = await generateAuditReport(user.id, req.body || {});

  if (results.filterError) {
    return res.status(200).json({ ok: false, message: results.filterError, report: null, matched: false });
  }

  return res.status(200).json({
    ok: true,
    report: results.report || null,
    matched: Boolean(results.report)
  });
}

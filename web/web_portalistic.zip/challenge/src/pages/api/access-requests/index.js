import { spawn } from 'child_process';
import { ensureMethod, guardCsrf, parseJsonBody } from '../../../lib/request';
import { isAllowedUrl } from '../../../utils/bot';

export const config = { api: { bodyParser: false } };

function runBotVisit(companyUrl) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ['/app/utils/bot.js', companyUrl], {
      cwd: '/app',
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe']
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (chunk) => {
      const text = chunk.toString();
      stdout += text;
      process.stdout.write(text);
    });

    child.stderr.on('data', (chunk) => {
      const text = chunk.toString();
      stderr += text;
      process.stderr.write(text);
    });

    child.on('error', reject);
    child.on('close', (code) => {
      resolve({
        code,
        stdout: stdout.trim(),
        stderr: stderr.trim()
      });
    });
  });
}

export default async function handler(req, res) {
  if (!ensureMethod(req, res, ['POST'])) return;
  if (!guardCsrf(req, res)) return;
  if (!(await parseJsonBody(req, res))) return;

  const { email, code, companyUrl } = req.body || {};
  if (!email || !code || !companyUrl) {
    return res.status(400).json({ ok: false, message: 'Email, code, and company URL are required.' });
  }

  try {
    const normalizedUrl = String(companyUrl).trim();
    if (!isAllowedUrl(normalizedUrl)) {
      return res.status(400).json({ ok: false, message: 'Only http and https URLs are allowed.' });
    }

    const result = await runBotVisit(normalizedUrl);
    if (result.code === 0) {
      return res.status(200).json({ ok: true, message: 'Admin reviewed the supplied link successfully.' });
    }

    return res.status(502).json({
      ok: false,
      message: result.stderr || result.stdout || 'The admin visit did not complete successfully.'
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      ok: false,
      message: error.message || 'Approval request could not be created.'
    });
  }
}

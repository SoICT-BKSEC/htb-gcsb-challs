import { useState } from 'react';
import { useRouter } from 'next/router';
import { useTranslation } from 'next-i18next/pages';
import PublicShell from '../components/PublicShell';
import { requireGuest } from '../lib/pageProps';

export default function LoginPage() {
  const { t } = useTranslation('common');
  const router = useRouter();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setLoading(true);
    setError('');

    const formData = new FormData(event.currentTarget);
    const payload = Object.fromEntries(formData.entries());

    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (!response.ok) {
      if (result.redirectTo) {
        router.push(result.redirectTo);
        return;
      }
      setError(result.message || t('auth.errors.invalid'));
      setLoading(false);
      return;
    }

    router.push(result.redirectTo || '/dashboard');
  }

  return (
    <PublicShell title={t('auth.loginTitle')} intro={t('auth.loginIntro')}>
      <section className="public-section narrow-section">
        <form className="stacked-form form-shell" onSubmit={handleSubmit}>
          <label>
            <span>{t('auth.email')}</span>
            <input name="email" type="email" required />
          </label>
          <label>
            <span>{t('auth.password')}</span>
            <input name="password" type="password" required />
          </label>
          <div className="actions">
            <button className="primary-button" type="submit" disabled={loading}>
              {loading ? t('shared.loading') : t('auth.login')}
            </button>
          </div>
          {error ? <p className="form-error">{error}</p> : null}
        </form>
      </section>
    </PublicShell>
  );
}

export const getServerSideProps = requireGuest;

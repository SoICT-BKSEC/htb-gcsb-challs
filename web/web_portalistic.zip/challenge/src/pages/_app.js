import '../styles/globals.css';
import { appWithTranslation } from 'next-i18next/pages';
import { Bricolage_Grotesque, Manrope } from 'next/font/google';
import nextConfig from '../next.config';

const bodyFont = Manrope({
  subsets: ['latin'],
  variable: '--font-sans'
});

const displayFont = Bricolage_Grotesque({
  subsets: ['latin'],
  variable: '--font-serif'
});

function MyApp({ Component, pageProps }) {
  return (
    <main className={`${bodyFont.variable} ${displayFont.variable}`}>
      <Component {...pageProps} />
    </main>
  );
}

export default appWithTranslation(MyApp, { i18n: nextConfig.i18n });

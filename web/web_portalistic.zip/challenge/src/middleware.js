import { NextResponse } from 'next/server';

export function middleware(request) {

  if (request.method !== 'POST') {
    return NextResponse.next();
  }

  // We identified some security issues with the file upload, so this feature is
  // disabled for the time being while the backend flow is being reviewed.
  return NextResponse.json(
    {
      ok: false,
      message: 'File uploads are temporarily unavailable.'
    },
    { status: 403 }
  );
}

export const config = {
  matcher: ['/documents', '/:locale/documents']
};

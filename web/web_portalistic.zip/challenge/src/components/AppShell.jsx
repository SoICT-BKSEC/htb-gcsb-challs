import Link from 'next/link';
import { useRouter } from 'next/router';
import { useTranslation } from 'next-i18next/pages';
import LanguageToggle from './LanguageToggle';

function getInitials(name) {
  return (
    String(name || '')
      .split(/\s+/)
      .map((w) => w[0] || '')
      .join('')
      .toUpperCase()
      .slice(0, 2) || '?'
  );
}

/* ── Inline SVG nav icons ── */
const IconGrid = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
    <rect x="1" y="1" width="5.2" height="5.2" rx="1.1" fill="currentColor" fillOpacity=".9" />
    <rect x="7.8" y="1" width="5.2" height="5.2" rx="1.1" fill="currentColor" fillOpacity=".9" />
    <rect x="1" y="7.8" width="5.2" height="5.2" rx="1.1" fill="currentColor" fillOpacity=".9" />
    <rect x="7.8" y="7.8" width="5.2" height="5.2" rx="1.1" fill="currentColor" fillOpacity=".9" />
  </svg>
);

const IconDoc = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
    <path
      d="M2 1.5h6.5l3 3V12a.5.5 0 01-.5.5H2a.5.5 0 01-.5-.5V2A.5.5 0 012 1.5z"
      stroke="currentColor"
      strokeWidth="1.15"
      strokeLinejoin="round"
    />
    <path d="M8.5 1.5V4.5H11.5" stroke="currentColor" strokeWidth="1.15" strokeLinejoin="round" />
    <path d="M4 7.5h6M4 10h4" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" />
  </svg>
);

const IconPayment = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
    <rect x="1" y="2.5" width="12" height="9" rx="1.5" stroke="currentColor" strokeWidth="1.15" />
    <path d="M1 5.5h12" stroke="currentColor" strokeWidth="1.15" />
    <path d="M3.5 8.5h3" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" />
    <circle cx="10.5" cy="8.5" r="1" fill="currentColor" fillOpacity=".7" />
  </svg>
);

const IconPeople = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
    <circle cx="5" cy="4.5" r="2" stroke="currentColor" strokeWidth="1.15" />
    <path
      d="M1 12c0-2.2 1.8-4 4-4s4 1.8 4 4"
      stroke="currentColor"
      strokeWidth="1.15"
      strokeLinecap="round"
    />
    <circle cx="10.5" cy="4.5" r="1.5" stroke="currentColor" strokeWidth="1.05" />
    <path
      d="M12.8 12c0-1.65-1.03-3-2.3-3"
      stroke="currentColor"
      strokeWidth="1.05"
      strokeLinecap="round"
    />
  </svg>
);

const IconSearch = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
    <circle cx="5.8" cy="5.8" r="3.8" stroke="currentColor" strokeWidth="1.15" />
    <path d="M9 9l3 3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
  </svg>
);

const NAV_ICONS = {
  '/dashboard':       <IconGrid />,
  '/documents':       <IconDoc />,
  '/payments':        <IconPayment />,
  '/admin/dashboard': <IconGrid />,
  '/admin/suppliers': <IconPeople />,
  '/admin/payments':  <IconPayment />,
  '/admin/audit':     <IconSearch />,
};

function navigationForRole(role, t) {
  if (role === 'supplier') {
    return [
      { href: '/dashboard', label: t('nav.dashboard') },
      { href: '/documents', label: t('nav.documents') },
      { href: '/payments',  label: t('nav.payments') },
    ];
  }
  return [
    { href: '/admin/dashboard', label: t('nav.adminDashboard') },
    { href: '/admin/suppliers', label: t('nav.adminSuppliers') },
    { href: '/admin/payments',  label: t('nav.adminPayments') },
    { href: '/admin/audit',     label: t('nav.adminAudit') },
  ];
}

export default function AppShell({ currentUser, title, intro, children }) {
  const router = useRouter();
  const { t } = useTranslation('common');
  const navigation = navigationForRole(currentUser.role, t);
  const homeHref = currentUser.role === 'supplier' ? '/dashboard' : '/admin/dashboard';

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  }

  return (
    <div className="app-shell">

      {/* ─────────── TOP NAVIGATION BAR ─────────── */}
      <header className="shell-bar">
        <div className="shell-brand">
          <Link className="brand-link" href={homeHref}>
            {t('brand.name')}
          </Link>
        </div>

        {/* Center: horizontal nav tabs */}
        <nav className="shell-nav" aria-label="Main navigation">
          {navigation.map((item) => (
            <Link
              key={item.href}
              className={router.pathname === item.href ? 'shell-nav-link active' : 'shell-nav-link'}
              href={item.href}
            >
              {NAV_ICONS[item.href]}
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Right: user chip + actions */}
        <div className="shell-actions">
          <div className="shell-user-chip">
            <div className="shell-avatar">{getInitials(currentUser.displayName)}</div>
            <span className="shell-username">{currentUser.displayName}</span>
          </div>
          <LanguageToggle />
          <button className="secondary-button" type="button" onClick={handleLogout}>
            {t('auth.logout')}
          </button>
        </div>
      </header>

      {/* ─────────── MAIN CONTENT AREA (full width) ─────────── */}
      <main className="app-main">
        <header className="page-banner">
          <div className="page-banner-text">
            <p className="section-tag">{t('shared.workspace')}</p>
            <h1>{title}</h1>
            {intro ? <p className="lead-copy">{intro}</p> : null}
          </div>
        </header>

        <div className="app-stage">
          {children}
        </div>
      </main>

    </div>
  );
}

import Link from 'next/link';
import Image from 'next/image';
import { useTranslation } from 'next-i18next/pages';
import LanguageToggle from './LanguageToggle';

export default function PublicShell({ title, intro, pills, children }) {
  const { t } = useTranslation('common');
  const isHero = !children;

  return (
    <div className="public-shell">

      {/* ─────────── LEFT PANEL ─────────── */}
      <div className="public-left">
        <header className="public-header">
          <Link className="brand-link" href="/">
            {t('brand.name')}
          </Link>
          <div className="public-header-actions">
            <LanguageToggle />
            <Link className="secondary-button link-button" href="/login">
              {t('auth.login')}
            </Link>
          </div>
        </header>

        <div className="public-body">
          {isHero ? (
            /* ── Index / hero page ── */
            <div className="hero-content">
              <p className="section-tag hero-tag">{t('brand.eyebrow')}</p>
              <h1>{title}</h1>
              {intro ? <p className="lead-copy">{intro}</p> : null}
              {pills && pills.length > 0 ? (
                <div className="hero-pills">
                  {pills.map((pill) => (
                    <span key={pill} className="hero-pill">{pill}</span>
                  ))}
                </div>
              ) : null}
              <div className="hero-actions">
                <Link className="primary-button link-button" href="/signup">
                  {t('auth.signup')}
                </Link>
                <Link className="secondary-button link-button" href="/login">
                  {t('auth.login')}
                </Link>
              </div>
            </div>
          ) : (
            /* ── Auth / form pages ── */
            <div className="form-panel">
              <div className="form-panel-header">
                <h1>{title}</h1>
                {intro ? <p className="lead-copy">{intro}</p> : null}
              </div>
              {children}
            </div>
          )}
        </div>
      </div>

      {/* ─────────── RIGHT PANEL (sticky CTA image) ─────────── */}
      <div className="public-right">
        <div className="public-right-overlay" />
        <Image
          src="/images/hero-cta.webp"
          alt=""
          fill
          sizes="55vw"
          priority
          style={{ objectFit: 'cover', objectPosition: 'center 30%' }}
        />
      </div>

    </div>
  );
}

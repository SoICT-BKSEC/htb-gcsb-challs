import Link from 'next/link';
import { useRouter } from 'next/router';
import { useTranslation } from 'next-i18next/pages';

export default function LanguageToggle() {
  const router = useRouter();
  const { t } = useTranslation('common');
  const locale = router.locale || 'en';
  const otherLocale = locale === 'en' ? 'id' : 'en';

  return (
    <Link className="ghost-link" href={router.asPath} locale={otherLocale}>
      {t('shared.switchLanguage')}: {otherLocale.toUpperCase()}
    </Link>
  );
}

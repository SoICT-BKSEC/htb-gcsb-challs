export default function TableCard({ title, description, columns, rows, renderRow }) {
  return (
    <section className="surface-card table-card">
      <div className="card-header">
        <div className="card-copy">
          <h2>{title}</h2>
          <p>{description}</p>
        </div>
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              {columns.map((column) => (
                <th key={column}>{column}</th>
              ))}
            </tr>
          </thead>
          <tbody>{rows.length > 0 ? rows.map(renderRow) : <tr><td className="empty-state" colSpan={columns.length}>No entries</td></tr>}</tbody>
        </table>
      </div>
    </section>
  );
}

const fs = require('node:fs');
const { firefox } = require('playwright');

const CONFIG = {
  appUrl: 'http://127.0.0.1:3000',
  visitTimeoutMs: 15000,
  idleWaitMs: 10000,
  adminEmail: 'admin.recovery@korvia.kv',
  adminPassword: '',
  adminCredentialsPath: '/app/runtime/admin-credentials.txt'
};
const allowedUrlPattern = /^https?:\/\/.+$/i;

const browserArgs = {
  headless: true,
  args: [
    '--disable-dev-shm-usage',
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-gpu',
    '--no-gpu',
    '--disable-default-apps',
    '--disable-translate',
    '--disable-device-discovery-notifications',
    '--disable-software-rasterizer',
    '--disable-xss-auditor'
  ]
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function timeoutAfter(ms) {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ timedOut: true }), ms);
  });
}

function isAllowedUrl(value) {
  return allowedUrlPattern.test(String(value || '').trim());
}

function readRuntimeAdminCredentials() {
  if (!fs.existsSync(CONFIG.adminCredentialsPath)) {
    return {
      email: CONFIG.adminEmail,
      password: CONFIG.adminPassword
    };
  }

  const contents = fs.readFileSync(CONFIG.adminCredentialsPath, 'utf8');
  const lines = contents.split(/\r?\n/);
  const entries = {};

  for (const line of lines) {
    const [key, ...rest] = line.split('=');
    if (!key) {
      continue;
    }

    entries[key.trim()] = rest.join('=').trim();
  }

  return {
    email: entries.email || CONFIG.adminEmail,
    password: entries.password || CONFIG.adminPassword
  };
}

async function loginAsAdmin(page) {
  const credentials = readRuntimeAdminCredentials();

  await page.goto(`${CONFIG.appUrl}/login`, {
    waitUntil: 'load',
    timeout: 10000
  });

  await page.fill('input[name="email"]', credentials.email);
  await page.fill('input[name="password"]', credentials.password);
  await Promise.all([
    page.waitForURL('**/admin/dashboard', { timeout: 10000 }),
    page.click('button[type="submit"]')
  ]);
}

async function visitUrl(urlToVisit, state) {
  if (!isAllowedUrl(urlToVisit)) {
    throw new Error('Only http and https URLs are allowed.');
  }

  console.log(`[bot] starting visit ${urlToVisit}`);

  const browser = await firefox.launch(browserArgs);
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  try {
    await loginAsAdmin(page);
    console.log('[bot] admin login complete');

    await page.goto(urlToVisit, {
      waitUntil: 'load',
      timeout: 10000
    });
    state.targetLoaded = true;
    console.log(`[bot] target loaded ${urlToVisit}`);

    await sleep(CONFIG.idleWaitMs);
    return true;
  } finally {
    await context.close().catch(() => {});
    await browser.close().catch(() => {});
  }
}

async function runCli() {
  const urlToVisit = String(process.argv[2] || '').trim();
  const state = { targetLoaded: false };

  if (!urlToVisit) {
    console.error('[bot] missing URL argument');
    process.exit(1);
    return;
  }

  try {
    const result = await Promise.race([
      visitUrl(urlToVisit, state),
      timeoutAfter(CONFIG.visitTimeoutMs)
    ]);

    if (result && result.timedOut) {
      if (state.targetLoaded) {
        console.log(`[bot] timeout after ${CONFIG.visitTimeoutMs}ms after target load`);
        console.log('[bot] visit complete');
        process.exit(0);
        return;
      }

      console.error(`[bot] timeout after ${CONFIG.visitTimeoutMs}ms`);
      process.exit(1);
      return;
    }

    console.log('[bot] visit complete');
    process.exit(0);
  } catch (error) {
    console.error('[bot] visit failed', error && error.stack ? error.stack : error);
    process.exit(1);
  }
}

if (require.main === module) {
  runCli();
}

module.exports = {
  config: CONFIG,
  isAllowedUrl,
  visitUrl
};

#!/usr/bin/env python3

import time

from dnslib import A, DNSRecord, QTYPE, RCODE, RR
from dnslib.server import BaseResolver, DNSServer


class WildcardResolver(BaseResolver):
    suffix_map = {
        "feed.beacon": "127.0.0.10",
        "ops.beacon": "127.0.0.11",
        "auth.beacon": "127.0.0.12",
    }

    def resolve(self, request: DNSRecord, _handler) -> DNSRecord:
        reply = request.reply()
        qname = str(request.q.qname).rstrip(".").lower()
        qtype = QTYPE[request.q.qtype]

        for suffix, address in self.suffix_map.items():
            if qname == suffix or qname.endswith(f".{suffix}"):
                if qtype in {"A", "ANY"}:
                    reply.add_answer(
                        RR(
                            rname=request.q.qname,
                            rtype=QTYPE.A,
                            rclass=1,
                            ttl=30,
                            rdata=A(address),
                        )
                    )
                else:
                    reply.header.rcode = RCODE.NXDOMAIN
                return reply

        reply.header.rcode = RCODE.NXDOMAIN
        return reply


if __name__ == "__main__":
    server = DNSServer(WildcardResolver(), port=53, address="0.0.0.0", tcp=False)
    server.start_thread()
    while True:
        time.sleep(60)

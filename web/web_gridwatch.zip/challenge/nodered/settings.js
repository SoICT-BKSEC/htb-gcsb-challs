module.exports = {
    uiHost: "127.0.0.11",
    uiPort: 80,
    adminAuth: false,
    userDir: "/data",
    flowFile: "flows.json",
    diagnostics: {
        enabled: false,
        ui: false,
    },
    functionExternalModules: false,
    logging: {
        console: {
            level: "info",
            metrics: false,
            audit: false,
        },
    },
    externalModules: {
        autoInstall: false,
        palette: {
            allowInstall: false,
            allowUpload: false,
        },
    },
};

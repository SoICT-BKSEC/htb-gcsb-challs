#!/usr/bin/env python3

from aiohttp import web

from controllers.handlers import index


app = web.Application()
app.router.add_get("/", index)


if __name__ == "__main__":
    web.run_app(app, host="127.0.0.10", port=80)

import pathlib
from jinja2 import Environment, FileSystemLoader, select_autoescape

_TEMPLATES_DIR = pathlib.Path(__file__).parent.parent / "templates"
_env = Environment(
    loader=FileSystemLoader(str(_TEMPLATES_DIR)),
    autoescape=select_autoescape(["html"]),
)


def render_feed_page(slug: str) -> str:
    return _env.get_template("feed.html").render(slug=slug)

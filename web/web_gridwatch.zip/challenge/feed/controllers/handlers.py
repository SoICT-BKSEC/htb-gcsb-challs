from aiohttp import web

from views.feed_view import render_feed_page


async def index(request: web.Request) -> web.Response:
    feed_host = request.headers.get("Host", "unknown").split(":", 1)[0]
    slug = feed_host.split(".", 1)[0]
    body = render_feed_page(slug)
    return web.Response(text=body, content_type="text/html")

#!/bin/bash
set -eu

echo 'nameserver 127.0.0.1' > /etc/resolv.conf

supervisord -c /etc/supervisor/supervisord.conf

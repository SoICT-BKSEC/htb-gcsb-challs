#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void) {
    char buffer[256];
    ssize_t read_count;
    int fd = open("/root/flag.txt", O_RDONLY);

    if (fd < 0) {
        fprintf(stderr, "open failed: %d\n", errno);
        return 1;
    }

    while ((read_count = read(fd, buffer, sizeof(buffer))) > 0) {
        if (write(STDOUT_FILENO, buffer, (size_t)read_count) != read_count) {
            close(fd);
            return 1;
        }
    }

    close(fd);
    return read_count < 0;
}

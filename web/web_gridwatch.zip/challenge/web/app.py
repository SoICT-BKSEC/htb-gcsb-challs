#!/usr/bin/env python3

import os

from aiohttp import web

from controllers.handlers import (
    access_denied,
    fetch_feed,
    index,
    login_page,
    logout,
    proxy_idp,
    sso_acs,
    sso_login,
)


BASE_DIR = os.path.dirname(__file__)
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = web.Application()
app.router.add_get("/", index)
app.router.add_get("/login", login_page)
app.router.add_get("/sso/login", sso_login)
app.router.add_post("/sso/acs", sso_acs)
app.router.add_get("/access-denied", access_denied)
app.router.add_get("/logout", logout)
app.router.add_static("/static/", STATIC_DIR, name="static")
app.router.add_route("*", "/idp/{tail:.*}", proxy_idp)
app.router.add_route("*", "/relay/{feed:[0-z]+}/", fetch_feed)


if __name__ == "__main__":
    web.run_app(
        app,
        host=os.environ.get("WEB_HOST", "127.0.0.1"),
        port=int(os.environ.get("WEB_PORT", "8081")),
    )

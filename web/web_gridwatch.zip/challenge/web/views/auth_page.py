import pathlib
from jinja2 import Environment, FileSystemLoader, select_autoescape

_TEMPLATES_DIR = pathlib.Path(__file__).parent.parent / "templates"
_env = Environment(
    loader=FileSystemLoader(str(_TEMPLATES_DIR)),
    autoescape=select_autoescape(["html"]),
)


def render_auth_page(
    *,
    title: str,
    eyebrow: str,
    heading: str,
    lede: str,
    panel_title: str,
    panel_body: str,
    detail_rows: list,
    action_links: list,
    support_link=None,
    metric_rows=None,
    # unused legacy params — keep for call-site compatibility:
    status_label: str = "",
    status_value: str = "",
    status_tone: str = "",
) -> str:
    return _env.get_template("auth_page.html").render(
        title=title,
        eyebrow=eyebrow,
        heading=heading,
        lede=lede,
        panel_title=panel_title,
        panel_body=panel_body,
        detail_rows=detail_rows,
        action_links=action_links,
        support_link=support_link,
        metric_rows=metric_rows,
    )

import html
import ipaddress
import pathlib
import socket

from aiohttp import ClientSession, web

from models.session import (
    SESSION_COOKIE,
    SESSION_TTL_SECONDS,
    create_session,
    destroy_session,
    get_session,
)
from views.auth_page import render_auth_page


AUTH_BASE = "http://127.0.0.12"

_BASE = pathlib.Path(__file__).parent.parent
with (_BASE / "templates" / "index.html").open(encoding="utf-8") as _f:
    _INDEX_HTML = _f.read()


_ALLOWED_RELAY_IPS = {
    ipaddress.ip_address("127.0.0.10"),  # *.feed.beacon
    ipaddress.ip_address("127.0.0.11"),  # ops.beacon (intended SSRF target)
}


def filter_bad_characters(text: str) -> str:
    for forbidden_char in ";<=>?@":
        text = text.replace(forbidden_char, ".")
    return text


def _relay_target_allowed(target_url: str) -> bool:
    try:
        from yarl import URL
        host = URL(target_url).host
        if not host:
            return False
        addr = socket.gethostbyname(host)
        return ipaddress.ip_address(addr) in _ALLOWED_RELAY_IPS
    except (OSError, ValueError):
        return False


def normalize_relay_path(raw_path: str) -> str:
    path = raw_path or "/"
    if not path.startswith("/"):
        path = f"/{path}"
    if ".." in path:
        return "/"
    return path


async def index(request: web.Request) -> web.Response:
    session = get_session(request)
    if session is None:
        raise web.HTTPFound("/login")

    name_id = html.escape(str(session.get("name_id", "unknown")))
    is_admin = bool(session.get("is_admin"))
    if not is_admin:
        raise web.HTTPFound("/access-denied")

    session_card = f"""
    <div style="position:fixed;top:1rem;right:1.25rem;z-index:30;display:flex;align-items:center;gap:.65rem;padding:.5rem .55rem .5rem .85rem;border:1px solid rgba(30,39,59,.88);border-radius:999px;background:rgba(6,8,13,.82);color:#e4e7ee;backdrop-filter:blur(10px);box-shadow:0 18px 40px rgba(0,0,0,.24);">
      <span style="max-width:min(38vw,320px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#a0a8ba;font-size:.84rem;">{name_id}</span>
      <a href="/logout" style="display:inline-flex;align-items:center;justify-content:center;min-height:2.25rem;padding:0 .9rem;border-radius:999px;border:1px solid #1e273b;background:#141b2b;color:#e4e7ee;text-decoration:none;font-weight:600;font-size:.9rem;">Logout</a>
    </div>
      <div style="display:none;">
        <p style="margin:0 0 .35rem;">Identity: <strong>{name_id}</strong></p>
        <p style="margin:0 0 .35rem;">Role: <strong>admin</strong></p>
        <p style="margin:0;"><code>/relay/&#123;payload&#125;/</code> is enabled for this session.</p>
      </div>
    </section>
    """
    body = f"""<!doctype html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">
    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>
    <link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap\" rel=\"stylesheet\">
    <title>GridWatch Portal</title>
  </head>
  <body>
    {_INDEX_HTML}
    {session_card}
  </body>
</html>"""
    return web.Response(text=body, content_type="text/html")


async def sso_login(_: web.Request) -> web.Response:
    raise web.HTTPFound("/idp/sso?acs=/sso/acs")


async def login_page(request: web.Request) -> web.Response:
    session = get_session(request)
    if session is not None and bool(session.get("is_admin")):
        raise web.HTTPFound("/")
    page = render_auth_page(
        title="GridWatch Sign In",
        eyebrow="Authorized personnel only",
        heading="Sign in to GridWatch.",
        lede="Use your Korvia GridWatch operator credentials to continue. Access is restricted to authorized grid personnel. Sessions are logged and audited.",
        status_label="Access state",
        status_value="sign-in required",
        status_tone="warn",
        panel_title="Continue with GridWatch Identity",
        panel_body="You will be redirected to the GridWatch sign-in page. After verification, GridWatch returns you to this portal.",
        detail_rows=[],
        action_links=[
            ("/sso/login", "Continue", "button"),
            ("/", "Back to GridWatch", "button-secondary"),
        ],
        support_link=("/idp/sso", "Open identity portal", "Sign-in help"),
        metric_rows=None,
    )
    return web.Response(text=page, content_type="text/html")


async def access_denied(request: web.Request) -> web.Response:
    session = get_session(request)
    if session is None:
        raise web.HTTPFound("/login")
    if bool(session.get("is_admin")):
        raise web.HTTPFound("/")

    name_id = html.escape(str(session.get("name_id", "unknown")))
    page = render_auth_page(
        title="GridWatch Access Denied",
        eyebrow="Policy gate",
        heading="This account cannot access GridWatch.",
        lede=f"{name_id} signed in successfully, but this portal is not available for the account.",
        status_label="Authorization",
        status_value="not assigned",
        status_tone="danger",
        panel_title="Access request needed",
        panel_body="Ask your manager or service desk to add this app to your GridWatch account, then sign in again.",
        detail_rows=[
            ("Signed in as", name_id),
            ("Application", "GridWatch Portal"),
            ("Access", "Not assigned"),
        ],
        action_links=[
            ("/logout", "Logout", "button"),
            ("/idp/sso", "Use another account", "button-secondary"),
        ],
        support_link=("/", "Return to GridWatch", "Service home"),
        metric_rows=None,
    )
    return web.Response(text=page, content_type="text/html")


async def sso_acs(request: web.Request) -> web.Response:
    form = await request.post()
    saml_response = form.get("SAMLResponse", "")

    if not saml_response:
        return web.Response(text="Missing SAMLResponse", status=400)

    async with ClientSession() as session:
        try:
            async with session.post(
                f"{AUTH_BASE}/api/verify",
                data={"SAMLResponse": saml_response},
            ) as verify_response:
                verify_data = await verify_response.json(content_type=None)
        except Exception as exc:
            return web.Response(text=f"SSO verification backend failed: {exc}", status=500)

    if not verify_data.get("ok"):
        reason = verify_data.get("error", "unknown verification failure")
        return web.Response(text=f"SSO verification failed: {reason}", status=403)

    session_payload = {
        "name_id": str(verify_data.get("name_id", "")),
        "is_admin": bool(verify_data.get("is_admin", False)),
    }
    session_id = create_session(session_payload)

    destination = "/" if session_payload["is_admin"] else "/access-denied"
    response = web.HTTPFound(destination)
    response.set_cookie(
        SESSION_COOKIE,
        session_id,
        httponly=True,
        samesite="Lax",
        max_age=SESSION_TTL_SECONDS,
    )
    return response


async def logout(request: web.Request) -> web.Response:
    destroy_session(request)
    response = web.HTTPFound("/")
    response.del_cookie(SESSION_COOKIE)
    return response


async def proxy_idp(request: web.Request) -> web.Response:
    tail = request.match_info.get("tail", "")
    target = f"{AUTH_BASE}/idp/{tail}"

    data = None
    if request.method in {"POST", "PUT", "PATCH"}:
        data = await request.post()

    async with ClientSession() as session:
        try:
            async with session.request(
                request.method,
                target,
                params=request.query,
                data=data,
                allow_redirects=False,
            ) as upstream:
                body = await upstream.read()
                headers = {}
                content_type = upstream.headers.get("Content-Type")
                if content_type:
                    headers["Content-Type"] = content_type
                location = upstream.headers.get("Location")
                if location:
                    headers["Location"] = location

                return web.Response(status=upstream.status, body=body, headers=headers)
        except Exception as exc:
            return web.Response(text=f"IDP proxy error: {exc}", status=500)


async def fetch_feed(request: web.Request) -> web.Response:
    session = get_session(request)
    if session is None:
        return web.Response(text="SSO session required", status=403)
    if not bool(session.get("is_admin")):
        return web.Response(text="Admin session required", status=403)

    feed = filter_bad_characters(request.match_info["feed"])
    relay_path = normalize_relay_path(request.query.get("path", "/"))
    target = f"http://{feed}.feed.beacon:80{relay_path}"
    if not _relay_target_allowed(target):
        return web.Response(text="Feed target not reachable", status=502)

    body = None
    headers = {}
    if request.method in {"POST", "PUT", "PATCH"}:
        body = await request.read()
        content_type = request.headers.get("Content-Type")
        if content_type:
            headers["Content-Type"] = content_type

    async with ClientSession() as client:
        try:
            async with client.request(
                request.method,
                target,
                data=body,
                headers=headers,
            ) as response:
                payload = await response.read()
                response_headers = {}
                content_type = response.headers.get("Content-Type")
                if content_type:
                    response_headers["Content-Type"] = content_type

                marker = f"\n<!-- fetched from {response.url} -->".encode()
                if content_type and "text/" in content_type:
                    payload += marker

                return web.Response(
                    status=response.status,
                    body=payload,
                    headers=response_headers,
                )
        except Exception as exc:
            return web.Response(
                text=f"Error fetching feed '{feed}' via {relay_path}: {exc}",
                status=500,
            )

import secrets
from typing import Any

from aiohttp import web


SESSION_COOKIE = "beacon_session"
SESSION_TTL_SECONDS = 3600

SESSIONS: dict[str, dict[str, Any]] = {}


def get_session(request: web.Request) -> dict[str, Any] | None:
    session_id = request.cookies.get(SESSION_COOKIE)
    if session_id is None:
        return None
    return SESSIONS.get(session_id)


def create_session(payload: dict[str, Any]) -> str:
    session_id = secrets.token_urlsafe(24)
    SESSIONS[session_id] = payload
    return session_id


def destroy_session(request: web.Request) -> None:
    session_id = request.cookies.get(SESSION_COOKIE)
    if session_id is not None:
        SESSIONS.pop(session_id, None)

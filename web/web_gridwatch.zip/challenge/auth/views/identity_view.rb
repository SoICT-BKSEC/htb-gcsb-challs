# frozen_string_literal: true

IDP_PAGE_STYLE = <<~HTML
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>
    :root {
      color-scheme: dark;
      --bg: #06080d;
      --surface: rgba(13, 19, 32, 0.92);
      --surface-2: #141b2b;
      --edge: #1e273b;
      --edge-soft: rgba(30, 39, 59, 0.55);
      --text: #e4e7ee;
      --muted: #a0a8ba;
      --mute-2: #7a8499;
      --ember: #d4a054;
      --steel: #7aa8d8;
      --ok: #5ba98a;
      --warn: #d4a054;
      --shadow: 0 24px 80px rgba(0, 0, 0, 0.32);
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      font-family: "Inter", system-ui, -apple-system, sans-serif;
      background:
        radial-gradient(ellipse at 18% -8%, rgba(212, 160, 84, 0.12), transparent 45%),
        radial-gradient(ellipse at 100% 110%, rgba(122, 168, 216, 0.09), transparent 40%),
        linear-gradient(180deg, #050710 0%, var(--bg) 100%);
      color: var(--text);
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }
    a { color: inherit; text-decoration: none; }
    .shell {
      width: min(1120px, calc(100vw - 2rem));
      margin: 0 auto;
      padding: 1.4rem 0 2.4rem;
    }
    .nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      padding: 0.8rem 0.25rem 1.2rem;
      border-bottom: 1px solid var(--edge-soft);
    }
    .brand {
      display: inline-flex;
      align-items: center;
      gap: 0.8rem;
      color: var(--text);
    }
    .brand-mark {
      position: relative;
      width: 2.4rem;
      height: 2.4rem;
      border-radius: 999px;
      border: 1px solid rgba(212, 160, 84, 0.35);
      background:
        radial-gradient(circle at center, rgba(212, 160, 84, 0.22), transparent 62%),
        rgba(10, 14, 24, 0.82);
      box-shadow: inset 0 0 0 1px rgba(122, 168, 216, 0.08);
    }
    .brand-mark::before,
    .brand-mark::after {
      content: "";
      position: absolute;
      inset: 0.38rem;
      border-radius: 999px;
      border: 1px solid rgba(212, 160, 84, 0.42);
    }
    .brand-mark::after {
      inset: 0.76rem;
      background: var(--ember);
      border-color: transparent;
    }
    .brand-copy strong {
      display: block;
      font-size: 1rem;
      font-weight: 600;
      letter-spacing: 0.01em;
    }
    .brand-copy span,
    .nav-meta,
    .eyebrow,
    .metric-label,
    .detail strong,
    .support-link small {
      color: var(--mute-2);
      font-family: "JetBrains Mono", "IBM Plex Mono", ui-monospace, Menlo, monospace;
      font-size: 0.68rem;
      letter-spacing: 0.24em;
      text-transform: uppercase;
    }
    .hero {
      display: grid;
      grid-template-columns: minmax(0, 1.18fr) minmax(320px, 0.82fr);
      gap: 1.2rem;
      margin-top: 1.4rem;
      align-items: stretch;
    }
    .panel {
      position: relative;
      overflow: hidden;
      border: 1px solid var(--edge);
      border-radius: 20px;
      background: var(--surface);
      box-shadow: var(--shadow);
    }
    .panel::before {
      content: "";
      position: absolute;
      inset: 0 0 auto;
      height: 2px;
      background: linear-gradient(90deg, transparent, rgba(212, 160, 84, 0.9), transparent);
      opacity: 0.72;
    }
    .copy {
      padding: 2rem;
      display: flex;
      flex-direction: column;
      gap: 1.4rem;
      justify-content: space-between;
    }
    .copy h1 {
      margin: 0;
      font-size: clamp(2rem, 4vw, 3.2rem);
      line-height: 0.94;
      letter-spacing: -0.04em;
      font-weight: 600;
      max-width: 11ch;
    }
    .lede {
      margin: 1rem 0 0;
      max-width: 54ch;
      color: var(--muted);
      font-size: 1rem;
      line-height: 1.7;
    }
    .status-row {
      display: flex;
      flex-wrap: wrap;
      gap: 0.7rem;
      margin-top: 1.2rem;
    }
    .visual-frame {
      margin: 1.3rem 0 0;
      overflow: hidden;
      border: 1px solid rgba(54, 68, 93, 0.9);
      border-radius: 16px;
      background: #070b13;
      aspect-ratio: 16 / 9;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
    }
    .visual-frame img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .pill {
      display: inline-flex;
      align-items: center;
      gap: 0.55rem;
      padding: 0.72rem 0.95rem;
      border-radius: 999px;
      border: 1px solid var(--edge);
      background: rgba(20, 27, 43, 0.92);
      color: var(--muted);
      font-size: 0.88rem;
    }
    .pill strong {
      color: var(--text);
      font-size: 0.92rem;
      font-weight: 600;
    }
    .dot {
      width: 0.55rem;
      height: 0.55rem;
      border-radius: 999px;
      background: var(--ok);
      box-shadow: 0 0 0 0.32rem rgba(91, 169, 138, 0.12);
    }
    .dot.warn {
      background: var(--warn);
      box-shadow: 0 0 0 0.32rem rgba(212, 160, 84, 0.12);
    }
    .metrics {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 0.8rem;
    }
    .metric {
      padding: 0.95rem 1rem;
      border-radius: 16px;
      border: 1px solid var(--edge);
      background: rgba(8, 12, 21, 0.55);
    }
    .metric b {
      display: block;
      margin-top: 0.45rem;
      color: var(--text);
      font-size: 1rem;
      font-weight: 600;
      font-variant-numeric: tabular-nums;
    }
    .card {
      padding: 2rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      gap: 1.1rem;
      align-self: stretch;
    }
    .card h2 {
      margin: 0.2rem 0 0;
      font-size: 1.55rem;
      font-weight: 600;
      letter-spacing: -0.03em;
    }
    .card p {
      margin: 0;
      color: var(--muted);
      line-height: 1.65;
    }
    .detail-list {
      display: grid;
      gap: 0.8rem;
      margin: 0;
      padding: 0;
      list-style: none;
    }
    .detail {
      display: grid;
      gap: 0.2rem;
      padding: 0.85rem 0.95rem;
      border-radius: 14px;
      border: 1px solid var(--edge);
      background: rgba(20, 27, 43, 0.8);
    }
    .detail span {
      color: var(--text);
      font-weight: 500;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 0.8rem;
      margin-top: 0.35rem;
    }
    .button,
    .button-secondary,
    .button-ghost {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 3rem;
      padding: 0 1.15rem;
      border-radius: 12px;
      border: 1px solid transparent;
      font-weight: 600;
      font-size: 0.95rem;
      cursor: pointer;
      transition: transform 120ms ease, border-color 120ms ease, background 120ms ease;
      appearance: none;
      -webkit-appearance: none;
    }
    .button {
      color: #090d17;
      background: linear-gradient(135deg, #efc176 0%, var(--ember) 100%);
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2);
    }
    .button-secondary,
    .button-ghost {
      border-color: var(--edge);
      background: rgba(20, 27, 43, 0.84);
      color: var(--text);
    }
    .button-ghost {
      background: rgba(8, 12, 21, 0.58);
    }
    .button:hover,
    .button-secondary:hover,
    .button-ghost:hover,
    .support-link:hover {
      transform: translateY(-1px);
    }
    .support-link {
      display: inline-flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      padding: 0.9rem 1rem;
      border-radius: 14px;
      border: 1px solid var(--edge);
      background: rgba(8, 12, 21, 0.58);
    }
    .support-link span {
      color: var(--text);
      font-weight: 500;
    }
    .field {
      display: grid;
      gap: 0.45rem;
    }
    .field label {
      color: var(--muted);
      font-size: 0.9rem;
      font-weight: 500;
    }
    .field input {
      width: 100%;
      min-height: 3rem;
      padding: 0.85rem 0.95rem;
      border-radius: 12px;
      border: 1px solid var(--edge);
      background: rgba(8, 12, 21, 0.72);
      color: var(--text);
      font: inherit;
      outline: none;
    }
    .field input:focus {
      border-color: rgba(212, 160, 84, 0.85);
      box-shadow: 0 0 0 0.2rem rgba(212, 160, 84, 0.14);
    }
    .hint {
      margin: 0;
      color: var(--mute-2);
      font-size: 0.82rem;
      line-height: 1.6;
    }
    .email-chip {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      padding: 0.72rem 0.95rem;
      border-radius: 12px;
      border: 1px solid var(--edge);
      background: rgba(8, 12, 21, 0.55);
      color: var(--muted);
      font-family: "JetBrains Mono", "IBM Plex Mono", ui-monospace, Menlo, monospace;
      font-size: 0.82rem;
      letter-spacing: 0.01em;
      margin-bottom: 0.8rem;
    }
    .email-chip::before {
      content: "";
      display: inline-block;
      width: 0.5rem;
      height: 0.5rem;
      border-radius: 50%;
      background: var(--ok);
      flex-shrink: 0;
    }
    .check-row {
      display: flex;
      align-items: center;
      gap: 0.55rem;
      color: var(--muted);
      font-size: 0.88rem;
      cursor: pointer;
      margin-top: 0.6rem;
      user-select: none;
    }
    .check-row input[type="checkbox"] {
      width: 1rem;
      height: 1rem;
      accent-color: var(--ember);
      flex-shrink: 0;
    }
    .spinner-wrap {
      display: flex;
      justify-content: center;
      padding: 0.5rem 0 1.25rem;
    }
    @keyframes idp-spin {
      to { transform: rotate(360deg); }
    }
    .spinner {
      width: 1.5rem;
      height: 1.5rem;
      border: 2px solid var(--edge);
      border-top-color: var(--ember);
      border-radius: 50%;
      animation: idp-spin 0.7s linear infinite;
    }
    .error-hint {
      margin: 0 0 1rem;
      padding: 0.75rem 0.95rem;
      border-radius: 10px;
      border: 1px solid rgba(218, 111, 111, 0.28);
      background: rgba(218, 111, 111, 0.07);
      color: #da6f6f;
      font-size: 0.88rem;
      line-height: 1.5;
    }
    code {
      padding: 0.18rem 0.35rem;
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.05);
      font-family: "JetBrains Mono", "IBM Plex Mono", ui-monospace, Menlo, monospace;
      font-size: 0.82em;
      color: #f0f3fa;
    }
    @media (max-width: 900px) {
      .hero { grid-template-columns: 1fr; }
      .copy { padding: 1.4rem; }
      .metrics { grid-template-columns: 1fr; }
      .copy h1 { max-width: none; }
    }
  </style>
HTML

def escape_html(text)
  Rack::Utils.escape_html(text.to_s)
end

def render_metrics(metric_rows)
  return "" if metric_rows.nil? || metric_rows.empty?

  items = metric_rows.map do |label, value|
    <<~HTML
      <div class="metric">
        <span class="metric-label">#{escape_html(label)}</span>
        <b>#{escape_html(value)}</b>
      </div>
    HTML
  end.join

  %(<div class="metrics">#{items}</div>)
end

def render_details(detail_rows)
  detail_rows.map do |label, value|
    <<~HTML
      <li class="detail">
        <strong>#{escape_html(label)}</strong>
        <span>#{escape_html(value)}</span>
      </li>
    HTML
  end.join
end

def render_actions(action_rows)
  action_rows.map do |href, label, css_class|
    %(<a class="#{escape_html(css_class)}" href="#{escape_html(href)}">#{escape_html(label)}</a>)
  end.join
end

def render_support_link(link)
  return "" if link.nil?

  href, label, caption = link
  <<~HTML
    <a class="support-link" href="#{escape_html(href)}">
      <div>
        <small>#{escape_html(caption)}</small>
        <span>#{escape_html(label)}</span>
      </div>
      <span aria-hidden="true">open</span>
    </a>
  HTML
end


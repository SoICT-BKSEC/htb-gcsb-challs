# frozen_string_literal: true

require "base64"
require "fileutils"
require "openssl"
require "securerandom"
require "samlr"
require "samlr/tools/certificate_builder"
require "samlr/tools/metadata_builder"
require "samlr/tools/response_builder"

Samlr.validation_mode = :log

ADMIN_EMAIL = "operator-admin@ops.beacon"
USER_EMAIL = "operator@ops.beacon"
DEFAULT_PASSWORD = "Gr1dWatch!"
CERTS_DIR = "/app/auth/certs"

def ensure_idp_material!
  FileUtils.mkdir_p(CERTS_DIR)
  key_path = File.join(CERTS_DIR, "idp_private_key.pem")
  cert_path = File.join(CERTS_DIR, "idp_certificate.pem")

  return if File.exist?(key_path) && File.exist?(cert_path)

  key = OpenSSL::PKey::RSA.new(2048)
  cert = OpenSSL::X509::Certificate.new
  cert.version = 2
  cert.serial = SecureRandom.random_number(1 << 31)
  cert.public_key = key.public_key
  cert.subject = OpenSSL::X509::Name.parse("/CN=beacon-auth-idp/O=GridWatch Operations/C=US")
  cert.issuer = cert.subject
  cert.not_before = Time.now - 60
  cert.not_after = Time.now + (3650 * 24 * 60 * 60)

  extensions = OpenSSL::X509::ExtensionFactory.new
  extensions.subject_certificate = cert
  extensions.issuer_certificate = cert
  cert.add_extension(extensions.create_extension("basicConstraints", "CA:TRUE", true))
  cert.add_extension(extensions.create_extension("keyUsage", "digitalSignature,keyEncipherment", true))
  cert.add_extension(extensions.create_extension("subjectKeyIdentifier", "hash"))
  cert.add_extension(extensions.create_extension("authorityKeyIdentifier", "keyid:always,issuer:always"))
  cert.sign(key, OpenSSL::Digest::SHA256.new)

  File.write(key_path, key.to_pem)
  File.write(cert_path, cert.to_pem)
end

def parse_saml_document!(saml_b64)
  Nokogiri::XML(Base64.strict_decode64(saml_b64)) do |config|
    config.nonet
  end
rescue StandardError
  raise "invalid SAMLResponse"
end

def verify_response!(saml_b64)
  parse_saml_document!(saml_b64)

  response = Samlr::Response.new(saml_b64, fingerprint: IDP_FINGERPRINT)
  response.verify!
  response
end

def admin_principal?(name_id)
  name_id.to_s.downcase == ADMIN_EMAIL.downcase
end

ensure_idp_material!
IDP_CERT = Samlr::Tools::CertificateBuilder.load(CERTS_DIR, "idp")
IDP_FINGERPRINT = Samlr::FingerprintSHA256.x509(IDP_CERT.x509)
SIGNED_METADATA = Samlr::Tools::MetadataBuilder.build(
  entity_id: "beacon-auth-idp",
  sign_metadata: true,
  certificate: IDP_CERT
)

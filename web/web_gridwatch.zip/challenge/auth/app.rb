#!/usr/bin/env ruby
# frozen_string_literal: true

require "sinatra"
require "json"
require "nokogiri"

set :bind, "127.0.0.12"
set :port, 80
set :environment, :production
set :logging, false
set :views, File.join(__dir__, "templates")

require_relative "models/identity"
require_relative "views/identity_view"
require_relative "controllers/identity_controller"

# frozen_string_literal: true

get "/" do
  erb :landing, locals: {
    title: "GridWatch Identity",
    eyebrow: "Korvia grid authority · single sign-on",
    heading: "Access GridWatch services with one account.",
    lede: "Sign in with your Korvia GridWatch operator account to continue to approved services. Keep this browser private if you are using a shared device.",
    metric_rows: [
      ["Identity status", "Online"],
      ["Active operators", "14"],
      ["Grid authority", "Korvia NGA"]
    ]
  }, layout: false
end

get "/idp/metadata" do
  [200, { "Content-Type" => "application/xml" }, SIGNED_METADATA]
end

get "/idp/sso" do
  acs = params["acs"].to_s
  acs = "/sso/acs" if acs.empty?
  escaped_acs = escape_html(acs)
  erb :sso, locals: {
    title: "GridWatch Sign In",
    eyebrow: "Sign in",
    heading: "Continue with your GridWatch account.",
    lede: "Enter your Korvia GridWatch email to continue. For your security, GridWatch may ask for additional verification on unfamiliar devices.",
    escaped_acs: escaped_acs,
    user_email: USER_EMAIL
  }, layout: false
end

post "/idp/auth" do
  acs = params["acs"].to_s
  acs = "/sso/acs" if acs.empty?
  escaped_acs = escape_html(acs)

  submitted_email = params["email"].to_s.strip
  submitted_password = params["password"].to_s

  unless submitted_password == DEFAULT_PASSWORD
    display_email = submitted_email.empty? ? USER_EMAIL : submitted_email
    status 401
    return erb :auth_error, locals: {
      title: "GridWatch Sign In",
      eyebrow: "Sign in",
      heading: "Continue with your GridWatch account.",
      lede: "Enter your Korvia GridWatch email to continue. For your security, GridWatch may ask for additional verification on unfamiliar devices.",
      escaped_acs: escaped_acs,
      display_email: display_email
    }, layout: false
  end

  name_id = if submitted_email.downcase.include?("admin") || submitted_email.empty?
              USER_EMAIL
            else
              submitted_email
            end

  signed_xml = Samlr::Tools::ResponseBuilder.build(
    destination: acs,
    in_response_to: Samlr::Tools.uuid,
    name_id: name_id,
    audience: "beacon-sso",
    not_on_or_after: Samlr::Tools::Timestamp.stamp(Time.now + 3600),
    not_before: Samlr::Tools::Timestamp.stamp(Time.now - 60),
    sign_assertion: false,
    sign_response: true,
    certificate: IDP_CERT
  )

  saml_b64 = Base64.strict_encode64(signed_xml)
  escaped_saml = escape_html(saml_b64)

  erb :redirecting, locals: {
    title: "GridWatch Redirecting",
    eyebrow: "Establishing session",
    heading: "Taking you back to GridWatch Portal.",
    lede: "Identity verified. Issuing your session token and returning you to the portal.",
    escaped_acs: escaped_acs,
    escaped_saml: escaped_saml
  }, layout: false
end

post "/api/verify" do
  saml_b64 = params["SAMLResponse"].to_s
  if saml_b64.empty?
    content_type :json
    status 400
    return JSON.generate({ ok: false, error: "missing SAMLResponse" })
  end

  begin
    response = verify_response!(saml_b64)
  rescue StandardError => e
    content_type :json
    status 403
    return JSON.generate({ ok: false, error: e.message })
  end

  name_id = response.name_id.to_s
  admin = admin_principal?(name_id)

  content_type :json
  JSON.generate({ ok: true, name_id: name_id, is_admin: admin })
end
